﻿namespace take_home_week_14_rayna
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cb_teamaway = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dtp_matchdate = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.cb_teamhome = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_matchid = new System.Windows.Forms.TextBox();
            this.dgv_data = new System.Windows.Forms.DataGridView();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).BeginInit();
            this.SuspendLayout();
            // 
            // cb_teamaway
            // 
            this.cb_teamaway.FormattingEnabled = true;
            this.cb_teamaway.Location = new System.Drawing.Point(563, 106);
            this.cb_teamaway.Margin = new System.Windows.Forms.Padding(2);
            this.cb_teamaway.Name = "cb_teamaway";
            this.cb_teamaway.Size = new System.Drawing.Size(174, 28);
            this.cb_teamaway.TabIndex = 18;
            this.cb_teamaway.SelectedValueChanged += new System.EventHandler(this.cb_teamaway_SelectedValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(445, 109);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 20);
            this.label5.TabIndex = 17;
            this.label5.Text = "Team Away";
            // 
            // dtp_matchdate
            // 
            this.dtp_matchdate.Location = new System.Drawing.Point(563, 41);
            this.dtp_matchdate.Margin = new System.Windows.Forms.Padding(2);
            this.dtp_matchdate.Name = "dtp_matchdate";
            this.dtp_matchdate.Size = new System.Drawing.Size(276, 26);
            this.dtp_matchdate.TabIndex = 16;
            this.dtp_matchdate.ValueChanged += new System.EventHandler(this.dtp_matchdate_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(445, 43);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 20);
            this.label4.TabIndex = 15;
            this.label4.Text = "Match Date";
            // 
            // cb_teamhome
            // 
            this.cb_teamhome.FormattingEnabled = true;
            this.cb_teamhome.Location = new System.Drawing.Point(165, 106);
            this.cb_teamhome.Margin = new System.Windows.Forms.Padding(2);
            this.cb_teamhome.Name = "cb_teamhome";
            this.cb_teamhome.Size = new System.Drawing.Size(174, 28);
            this.cb_teamhome.TabIndex = 14;
            this.cb_teamhome.SelectedValueChanged += new System.EventHandler(this.cb_teamhome_SelectedValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(47, 109);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 20);
            this.label3.TabIndex = 13;
            this.label3.Text = "Team Home";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 43);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "Match ID";
            // 
            // tb_matchid
            // 
            this.tb_matchid.Enabled = false;
            this.tb_matchid.Location = new System.Drawing.Point(165, 41);
            this.tb_matchid.Margin = new System.Windows.Forms.Padding(2);
            this.tb_matchid.Name = "tb_matchid";
            this.tb_matchid.Size = new System.Drawing.Size(176, 26);
            this.tb_matchid.TabIndex = 11;
            // 
            // dgv_data
            // 
            this.dgv_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_data.Location = new System.Drawing.Point(51, 155);
            this.dgv_data.Name = "dgv_data";
            this.dgv_data.RowHeadersWidth = 62;
            this.dgv_data.RowTemplate.Height = 28;
            this.dgv_data.Size = new System.Drawing.Size(534, 238);
            this.dgv_data.TabIndex = 19;
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Items.AddRange(new object[] {
            "GO",
            "GP",
            "GW",
            "CR",
            "CY",
            "PM"});
            this.cb_type.Location = new System.Drawing.Point(701, 311);
            this.cb_type.Margin = new System.Windows.Forms.Padding(2);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(174, 28);
            this.cb_type.TabIndex = 27;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(622, 314);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 20);
            this.label8.TabIndex = 26;
            this.label8.Text = "Type";
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(701, 266);
            this.cb_player.Margin = new System.Windows.Forms.Padding(2);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(174, 28);
            this.cb_player.TabIndex = 25;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(622, 269);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 20);
            this.label7.TabIndex = 24;
            this.label7.Text = "Player";
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(701, 221);
            this.cb_team.Margin = new System.Windows.Forms.Padding(2);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(174, 28);
            this.cb_team.TabIndex = 23;
            this.cb_team.SelectedValueChanged += new System.EventHandler(this.cb_team_SelectedValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(619, 224);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 20);
            this.label6.TabIndex = 22;
            this.label6.Text = "Team";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(617, 180);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 20);
            this.label2.TabIndex = 21;
            this.label2.Text = "Minute";
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(701, 179);
            this.tb_minute.Margin = new System.Windows.Forms.Padding(2);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(176, 26);
            this.tb_minute.TabIndex = 20;
            this.tb_minute.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_minute_KeyPress);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(783, 359);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(2);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(92, 34);
            this.btn_delete.TabIndex = 29;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(636, 359);
            this.btn_add.Margin = new System.Windows.Forms.Padding(2);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(92, 34);
            this.btn_add.TabIndex = 28;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(352, 410);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(233, 34);
            this.btn_insert.TabIndex = 30;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(948, 509);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.dgv_data);
            this.Controls.Add(this.cb_teamaway);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dtp_matchdate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cb_teamhome);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_matchid);
            this.Name = "Form1";
            this.Text = "   ";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cb_teamaway;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtp_matchdate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cb_teamhome;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_matchid;
        private System.Windows.Forms.DataGridView dgv_data;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_insert;
    }
}

