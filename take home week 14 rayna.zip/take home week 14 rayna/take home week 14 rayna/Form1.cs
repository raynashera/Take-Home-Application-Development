﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace take_home_week_14_rayna
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dtteamhome = new DataTable();
        DataTable dtteamaway = new DataTable();
        DataTable dtType = new DataTable();
        DataTable data = new DataTable();
        DataTable dtPlayer = new DataTable();
        DataTable dtTeamKepilih = new DataTable();
        DataTable dtMatch = new DataTable();
        DataTable dtMatchDate = new DataTable();
        DataTable dtDMatch = new DataTable();

        string sqlquery;
        string matchdate;

        int goalhome = 0;
        int goalaway = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                data = new DataTable();
                data.Columns.Add("Team");
                data.Columns.Add("Player");
                data.Columns.Add("Type");

                dtDMatch = new DataTable();
                dtDMatch.Columns.Add("Match ID");
                dtDMatch.Columns.Add("Minute");
                dtDMatch.Columns.Add("Team ID");
                dtDMatch.Columns.Add("Player ID");
                dtDMatch.Columns.Add("Type");

                sqlConnect = new MySqlConnection("server=localhost;uid=root;pwd=Flawless1645;database=premier_league");
                sqlConnect.Open();
                sqlConnect.Close();

                string sql = "select team_name, team_id from team;";
                sqlCommand = new MySqlCommand(sql, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                dtteamhome = new DataTable();
                sqlDataAdapter.Fill(dtteamhome);
                dtteamaway = new DataTable();
                sqlDataAdapter.Fill(dtteamaway);

                cb_teamhome.DataSource = dtteamhome;
                cb_teamhome.DisplayMember = "team_name";
                cb_teamhome.ValueMember = "team_id";

                cb_teamhome.Text = "";

                cb_teamaway.DataSource = dtteamaway;
                cb_teamaway.DisplayMember = "team_name";
                cb_teamaway.ValueMember = "team_id";

                cb_teamaway.Text = "";

                dtType = new DataTable();
                dtType.Columns.Add("type_id");
                dtType.Columns.Add("type_name");
                dtType.Rows.Add("GO", "Goal");
                dtType.Rows.Add("GP", "Goal Penalty");
                dtType.Rows.Add("GW", "Own Goal");
                dtType.Rows.Add("CR", "Red Card");
                dtType.Rows.Add("CY", "Yellow Card");
                dtType.Rows.Add("PM", "Penalty Miss");               

                cb_type.DataSource = dtType;
                cb_type.DisplayMember = "type_name";
                cb_type.ValueMember = "type_id";

                cb_team.Text = "";
                cb_type.Text = "";
                cb_player.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void cb_team_SelectedValueChanged(object sender, EventArgs e)
        {
            string value = "";
            if (cb_team.Text == cb_teamhome.Text)
            {
                value = cb_teamhome.SelectedValue.ToString();
            }
            else if (cb_team.Text == cb_teamaway.Text)
            {
                value = cb_teamaway.SelectedValue.ToString();
            }
            sqlquery = $"select player_name, player_id from player where '{cb_team.SelectedValue}' = team_id;";
            dtPlayer = new DataTable();
            
            sqlCommand = new MySqlCommand(sqlquery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtPlayer);

            cb_player.DataSource = dtPlayer;
            cb_player.DisplayMember = "player_name";
            cb_player.ValueMember = "player_id";
            cb_player.Text = "";
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (tb_minute.Text == "" || cb_team.Text == "" || cb_player.Text == "" || cb_type.Text == "" || tb_matchid.Text == "")
            {
                MessageBox.Show("Tidak boleh ada yang kosong");
            }
            else
            {
                if (cb_type.SelectedValue == "GO" || cb_type.SelectedValue == "GP")
                {
                    if (cb_teamaway.Text == cb_team.Text)
                    {
                        goalaway++;
                    }
                    else
                    {
                        goalhome++;
                    }
                }
                else if (cb_type.SelectedValue == "GW")
                {
                    if (cb_teamaway.Text == cb_team.Text)
                    {
                        goalhome++;
                    }
                    else
                    {
                        goalaway++;
                    }
                }

                dtDMatch.Rows.Add(tb_matchid.Text, tb_minute.Text, cb_team.SelectedValue, cb_player.SelectedValue, cb_type.SelectedValue);

                data.Rows.Add(cb_team.Text, cb_player.Text, cb_type.SelectedValue);
                dgv_data.DataSource = data;

                dgv_data.ClearSelection();

                cb_team.Text = "";
                cb_player.Text = "";
                cb_type.Text = "";
                tb_minute.Text = "";

            }

        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (data.Rows.Count == 0)
            {
                MessageBox.Show("Pilih kolom yang mau dihapus");
            }
            else
            {
                dgv_data.ClearSelection();

                DataGridViewRow currentRow = dgv_data.CurrentRow;
                int indexdelete = 0;

                if (dgv_data.Rows.Count != 0)
                {
                    for (int i = 0; i < data.Rows.Count; i++)
                    {
                        if (data.Rows[i][0].ToString().Contains(currentRow.Cells[0].Value.ToString()))
                        {
                            indexdelete = i;
                        }
                    }

                    if (currentRow.Cells[2].Value.ToString() == "GO" || currentRow.Cells[2].Value.ToString() == "GP")
                    {
                        if (cb_teamaway.Text == data.Rows[indexdelete][0].ToString())
                        {
                            goalaway--;
                        }
                        else
                        {
                            goalhome--;
                        }
                    }
                    else if (currentRow.Cells[2].Value.ToString() == "GW")
                    {
                        if (cb_teamaway.Text == data.Rows[indexdelete][0].ToString())
                        {
                            goalhome--;
                        }
                        else
                        {
                            goalaway--;
                        }
                    }

                    data.Rows.RemoveAt(indexdelete);
                    dtDMatch.Rows.RemoveAt(indexdelete);
                }
                dgv_data.DataSource = data;
            }
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            if (dtDMatch.Rows.Count == 0)
            {
                MessageBox.Show("Tidak ada data yang bisa di insert");
            }
            else if (dtDMatch.Rows.Count != 0)
            {
                for (int i = 0; i < dtDMatch.Rows.Count; i++)
                {
                    sqlquery = $"INSERT INTO dmatch VALUES ('{dtDMatch.Rows[i][0]}', '{dtDMatch.Rows[i][1]}', '{dtDMatch.Rows[i][2]}', '{dtDMatch.Rows[i][3]}', '{dtDMatch.Rows[i][4]}', '0')";
                    sqlConnect.Open();
                    sqlCommand = new MySqlCommand(sqlquery, sqlConnect);
                    sqlCommand.ExecuteNonQuery();
                    sqlConnect.Close();
                }

                sqlquery = $"INSERT INTO `match` VALUES ('{tb_matchid.Text}', '{matchdate}', '{cb_teamhome.SelectedValue}', '{cb_teamaway.SelectedValue}', '{goalhome.ToString()}', '{goalaway.ToString()}', 'M002', '0');";
                sqlConnect.Open();
                sqlCommand = new MySqlCommand(sqlquery, sqlConnect);
                sqlCommand.ExecuteNonQuery();
                sqlConnect.Close();

                data.Rows.Clear();
                dtDMatch.Rows.Clear();

                tb_matchid.Text = "";
                cb_teamhome.Text = "";
                cb_teamaway.Text = "";
            }
            goalhome = 0;
            goalaway = 0;

        }

        private void tb_minute_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void cb_teamhome_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                //cb_team.Items.Clear();
                if (data.Rows.Count != 0 && dtDMatch.Rows.Count != 0)
                {
                    data.Rows.Clear();
                    dtDMatch.Rows.Clear();
                }
                if (cb_teamhome.Text == cb_teamaway.Text)
                {
                    MessageBox.Show("Tim tidak Boleh sama");
                    cb_teamhome.Text = "";
                    cb_teamaway.Text = "";
                }

                else if (cb_teamaway.Text != "" && cb_teamhome.Text != "")
                {
                    dtTeamKepilih = new DataTable();
                    sqlquery = $"select team_name, team_id from team where '{cb_teamhome.SelectedValue}' = team_id OR '{cb_teamaway.SelectedValue}' = team_id;";
                    

                    sqlCommand = new MySqlCommand(sqlquery, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(dtTeamKepilih);

                    cb_team.DataSource = dtTeamKepilih;
                    cb_team.DisplayMember = "team_name";
                    cb_team.ValueMember = "team_id";
                    cb_team.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void cb_teamaway_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                //cb_team.Items.Clear();
                if (data.Rows.Count != 0 && dtDMatch.Rows.Count != 0)
                {
                    data.Rows.Clear();
                    dtDMatch.Rows.Clear();
                }
                if (cb_teamhome.Text == cb_teamaway.Text)
                {
                    MessageBox.Show("Tim tidak Boleh sama");
                    cb_teamhome.Text = "";
                    cb_teamaway.Text = "";
                }
                else if(cb_teamaway.Text != "" && cb_teamhome.Text != "")
                {
                    dtTeamKepilih = new DataTable();
                    sqlquery = $"select team_name, team_id from team where '{cb_teamhome.SelectedValue}' = team_id OR '{cb_teamaway.SelectedValue}' = team_id;";
                    
                    sqlCommand = new MySqlCommand(sqlquery, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(dtTeamKepilih);

                    cb_team.DataSource = dtTeamKepilih;
                    cb_team.DisplayMember = "team_name";
                    cb_team.ValueMember = "team_id";
                    cb_team.Text = "";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void dtp_matchdate_ValueChanged(object sender, EventArgs e)
        {
            dtMatch = new DataTable();
            sqlquery = $"SELECT match_date FROM `match`";
            sqlCommand = new MySqlCommand(sqlquery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtMatch);

            matchdate = dtp_matchdate.Value.Year.ToString() + '-' + dtp_matchdate.Value.Month.ToString() + '-' + dtp_matchdate.Value.Day.ToString();

            if (dtp_matchdate.Value < Convert.ToDateTime(dtMatch.Rows[dtMatch.Rows.Count - 1][0].ToString()))
            {
                MessageBox.Show($"Tanggal Pertandingan tidak boleh sebelum tanggal pertandingan terakhir");
            }
            else
            {
                sqlquery = $"SELECT COUNT(match_id) FROM `match` WHERE match_id LIKE '{dtp_matchdate.Value.Year}%'";
                dtMatchDate = new DataTable();
                sqlCommand = new MySqlCommand(sqlquery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtMatchDate);

                int lastmatchid = Convert.ToInt32(dtMatchDate.Rows[0][0]) + 1;

                if (lastmatchid < 10)
                {
                    tb_matchid.Text = $"{dtp_matchdate.Value.Year}00{lastmatchid}";
                }
                else if (lastmatchid < 100)
                {
                    tb_matchid.Text = $"{dtp_matchdate.Value.Year}0{lastmatchid}";
                }
                else
                {
                    tb_matchid.Text = $"{dtp_matchdate.Value.Year}{lastmatchid}";
                }
            }
        }

    }
}
