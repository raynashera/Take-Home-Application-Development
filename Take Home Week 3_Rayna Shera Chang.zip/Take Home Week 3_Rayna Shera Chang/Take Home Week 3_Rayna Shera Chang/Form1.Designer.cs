﻿namespace Take_Home_Week_3_Rayna_Shera_Chang
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_username = new System.Windows.Forms.TextBox();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_register = new System.Windows.Forms.Button();
            this.panel_register = new System.Windows.Forms.Panel();
            this.btn_register2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_password2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_username2 = new System.Windows.Forms.TextBox();
            this.panel_login = new System.Windows.Forms.Panel();
            this.panel_mainview = new System.Windows.Forms.Panel();
            this.btn_withdrawmain = new System.Windows.Forms.Button();
            this.btn_logoutmain = new System.Windows.Forms.Button();
            this.btn_depositmain = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.lb_balance = new System.Windows.Forms.Label();
            this.panel_deposit = new System.Windows.Forms.Panel();
            this.tb_deposit = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_logout2 = new System.Windows.Forms.Button();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.panel_withdraw = new System.Windows.Forms.Panel();
            this.tb_withdraw = new System.Windows.Forms.TextBox();
            this.btn_withdraw = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_logout3 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.lb_balance2 = new System.Windows.Forms.Label();
            this.panel_register.SuspendLayout();
            this.panel_login.SuspendLayout();
            this.panel_mainview.SuspendLayout();
            this.panel_deposit.SuspendLayout();
            this.panel_withdraw.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(163, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(187, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "UC Bank";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Username:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password:";
            // 
            // tb_username
            // 
            this.tb_username.Location = new System.Drawing.Point(122, 17);
            this.tb_username.Name = "tb_username";
            this.tb_username.Size = new System.Drawing.Size(193, 26);
            this.tb_username.TabIndex = 3;
            // 
            // tb_password
            // 
            this.tb_password.Location = new System.Drawing.Point(122, 58);
            this.tb_password.Name = "tb_password";
            this.tb_password.Size = new System.Drawing.Size(193, 26);
            this.tb_password.TabIndex = 4;
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(103, 111);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(119, 35);
            this.btn_login.TabIndex = 5;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_register
            // 
            this.btn_register.Location = new System.Drawing.Point(103, 154);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new System.Drawing.Size(119, 35);
            this.btn_register.TabIndex = 6;
            this.btn_register.Text = "Register";
            this.btn_register.UseVisualStyleBackColor = true;
            this.btn_register.Click += new System.EventHandler(this.btn_register_Click);
            // 
            // panel_register
            // 
            this.panel_register.Controls.Add(this.btn_register2);
            this.panel_register.Controls.Add(this.label5);
            this.panel_register.Controls.Add(this.tb_password2);
            this.panel_register.Controls.Add(this.label4);
            this.panel_register.Controls.Add(this.tb_username2);
            this.panel_register.Location = new System.Drawing.Point(104, 140);
            this.panel_register.Name = "panel_register";
            this.panel_register.Size = new System.Drawing.Size(323, 200);
            this.panel_register.TabIndex = 7;
            // 
            // btn_register2
            // 
            this.btn_register2.Location = new System.Drawing.Point(103, 113);
            this.btn_register2.Name = "btn_register2";
            this.btn_register2.Size = new System.Drawing.Size(119, 35);
            this.btn_register2.TabIndex = 13;
            this.btn_register2.Text = "Register";
            this.btn_register2.UseVisualStyleBackColor = true;
            this.btn_register2.Click += new System.EventHandler(this.btn_register2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Username:";
            // 
            // tb_password2
            // 
            this.tb_password2.Location = new System.Drawing.Point(122, 54);
            this.tb_password2.Name = "tb_password2";
            this.tb_password2.Size = new System.Drawing.Size(193, 26);
            this.tb_password2.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Password:";
            // 
            // tb_username2
            // 
            this.tb_username2.Location = new System.Drawing.Point(122, 13);
            this.tb_username2.Name = "tb_username2";
            this.tb_username2.Size = new System.Drawing.Size(193, 26);
            this.tb_username2.TabIndex = 10;
            // 
            // panel_login
            // 
            this.panel_login.Controls.Add(this.btn_register);
            this.panel_login.Controls.Add(this.label2);
            this.panel_login.Controls.Add(this.label3);
            this.panel_login.Controls.Add(this.btn_login);
            this.panel_login.Controls.Add(this.tb_username);
            this.panel_login.Controls.Add(this.tb_password);
            this.panel_login.Location = new System.Drawing.Point(104, 140);
            this.panel_login.Name = "panel_login";
            this.panel_login.Size = new System.Drawing.Size(323, 200);
            this.panel_login.TabIndex = 8;
            // 
            // panel_mainview
            // 
            this.panel_mainview.Controls.Add(this.btn_withdrawmain);
            this.panel_mainview.Controls.Add(this.btn_logoutmain);
            this.panel_mainview.Controls.Add(this.btn_depositmain);
            this.panel_mainview.Controls.Add(this.label6);
            this.panel_mainview.Controls.Add(this.lb_balance);
            this.panel_mainview.Location = new System.Drawing.Point(104, 115);
            this.panel_mainview.Name = "panel_mainview";
            this.panel_mainview.Size = new System.Drawing.Size(323, 225);
            this.panel_mainview.TabIndex = 9;
            // 
            // btn_withdrawmain
            // 
            this.btn_withdrawmain.Location = new System.Drawing.Point(123, 175);
            this.btn_withdrawmain.Name = "btn_withdrawmain";
            this.btn_withdrawmain.Size = new System.Drawing.Size(97, 31);
            this.btn_withdrawmain.TabIndex = 12;
            this.btn_withdrawmain.Text = "Withdraw";
            this.btn_withdrawmain.UseVisualStyleBackColor = true;
            this.btn_withdrawmain.Click += new System.EventHandler(this.btn_withdrawmain_Click);
            // 
            // btn_logoutmain
            // 
            this.btn_logoutmain.Location = new System.Drawing.Point(195, 9);
            this.btn_logoutmain.Name = "btn_logoutmain";
            this.btn_logoutmain.Size = new System.Drawing.Size(97, 31);
            this.btn_logoutmain.TabIndex = 10;
            this.btn_logoutmain.Text = "Log Out";
            this.btn_logoutmain.UseVisualStyleBackColor = true;
            this.btn_logoutmain.Click += new System.EventHandler(this.btn_logoutmain_Click);
            // 
            // btn_depositmain
            // 
            this.btn_depositmain.Location = new System.Drawing.Point(123, 138);
            this.btn_depositmain.Name = "btn_depositmain";
            this.btn_depositmain.Size = new System.Drawing.Size(97, 31);
            this.btn_depositmain.TabIndex = 11;
            this.btn_depositmain.Text = "Deposit";
            this.btn_depositmain.UseVisualStyleBackColor = true;
            this.btn_depositmain.Click += new System.EventHandler(this.btn_depositmain_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(41, 100);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Balance";
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_balance.Location = new System.Drawing.Point(125, 93);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(26, 29);
            this.lb_balance.TabIndex = 11;
            this.lb_balance.Text = "0";
            // 
            // panel_deposit
            // 
            this.panel_deposit.Controls.Add(this.tb_deposit);
            this.panel_deposit.Controls.Add(this.label7);
            this.panel_deposit.Controls.Add(this.btn_logout2);
            this.panel_deposit.Controls.Add(this.btn_deposit);
            this.panel_deposit.Location = new System.Drawing.Point(104, 115);
            this.panel_deposit.Name = "panel_deposit";
            this.panel_deposit.Size = new System.Drawing.Size(323, 225);
            this.panel_deposit.TabIndex = 13;
            // 
            // tb_deposit
            // 
            this.tb_deposit.Location = new System.Drawing.Point(77, 95);
            this.tb_deposit.Name = "tb_deposit";
            this.tb_deposit.Size = new System.Drawing.Size(165, 26);
            this.tb_deposit.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(75, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(169, 20);
            this.label7.TabIndex = 13;
            this.label7.Text = "Input Deposit Amount:";
            // 
            // btn_logout2
            // 
            this.btn_logout2.Location = new System.Drawing.Point(195, 9);
            this.btn_logout2.Name = "btn_logout2";
            this.btn_logout2.Size = new System.Drawing.Size(97, 31);
            this.btn_logout2.TabIndex = 10;
            this.btn_logout2.Text = "Log Out";
            this.btn_logout2.UseVisualStyleBackColor = true;
            this.btn_logout2.Click += new System.EventHandler(this.btn_logout2_Click);
            // 
            // btn_deposit
            // 
            this.btn_deposit.Location = new System.Drawing.Point(114, 138);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(97, 31);
            this.btn_deposit.TabIndex = 11;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // panel_withdraw
            // 
            this.panel_withdraw.Controls.Add(this.tb_withdraw);
            this.panel_withdraw.Controls.Add(this.btn_withdraw);
            this.panel_withdraw.Controls.Add(this.label10);
            this.panel_withdraw.Controls.Add(this.btn_logout3);
            this.panel_withdraw.Controls.Add(this.label8);
            this.panel_withdraw.Controls.Add(this.lb_balance2);
            this.panel_withdraw.Location = new System.Drawing.Point(104, 115);
            this.panel_withdraw.Name = "panel_withdraw";
            this.panel_withdraw.Size = new System.Drawing.Size(323, 225);
            this.panel_withdraw.TabIndex = 13;
            // 
            // tb_withdraw
            // 
            this.tb_withdraw.Location = new System.Drawing.Point(90, 137);
            this.tb_withdraw.Name = "tb_withdraw";
            this.tb_withdraw.Size = new System.Drawing.Size(165, 26);
            this.tb_withdraw.TabIndex = 16;
            // 
            // btn_withdraw
            // 
            this.btn_withdraw.Location = new System.Drawing.Point(123, 175);
            this.btn_withdraw.Name = "btn_withdraw";
            this.btn_withdraw.Size = new System.Drawing.Size(97, 31);
            this.btn_withdraw.TabIndex = 12;
            this.btn_withdraw.Text = "Withdraw";
            this.btn_withdraw.UseVisualStyleBackColor = true;
            this.btn_withdraw.Click += new System.EventHandler(this.btn_withdraw_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(77, 105);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(192, 20);
            this.label10.TabIndex = 15;
            this.label10.Text = "Input Withdrawal Amount:";
            // 
            // btn_logout3
            // 
            this.btn_logout3.Location = new System.Drawing.Point(195, 9);
            this.btn_logout3.Name = "btn_logout3";
            this.btn_logout3.Size = new System.Drawing.Size(97, 31);
            this.btn_logout3.TabIndex = 10;
            this.btn_logout3.Text = "Log Out";
            this.btn_logout3.UseVisualStyleBackColor = true;
            this.btn_logout3.Click += new System.EventHandler(this.btn_logout3_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(41, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 20);
            this.label8.TabIndex = 10;
            this.label8.Text = "Balance";
            // 
            // lb_balance2
            // 
            this.lb_balance2.AutoSize = true;
            this.lb_balance2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_balance2.Location = new System.Drawing.Point(125, 62);
            this.lb_balance2.Name = "lb_balance2";
            this.lb_balance2.Size = new System.Drawing.Size(26, 29);
            this.lb_balance2.TabIndex = 11;
            this.lb_balance2.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 425);
            this.Controls.Add(this.panel_withdraw);
            this.Controls.Add(this.panel_deposit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel_login);
            this.Controls.Add(this.panel_register);
            this.Controls.Add(this.panel_mainview);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_register.ResumeLayout(false);
            this.panel_register.PerformLayout();
            this.panel_login.ResumeLayout(false);
            this.panel_login.PerformLayout();
            this.panel_mainview.ResumeLayout(false);
            this.panel_mainview.PerformLayout();
            this.panel_deposit.ResumeLayout(false);
            this.panel_deposit.PerformLayout();
            this.panel_withdraw.ResumeLayout(false);
            this.panel_withdraw.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_username;
        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_register;
        private System.Windows.Forms.Panel panel_register;
        private System.Windows.Forms.Button btn_register2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_password2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_username2;
        private System.Windows.Forms.Panel panel_login;
        private System.Windows.Forms.Panel panel_mainview;
        private System.Windows.Forms.Button btn_logoutmain;
        private System.Windows.Forms.Button btn_withdrawmain;
        private System.Windows.Forms.Button btn_depositmain;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Panel panel_deposit;
        private System.Windows.Forms.TextBox tb_deposit;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btn_logout2;
        private System.Windows.Forms.Button btn_deposit;
        private System.Windows.Forms.Panel panel_withdraw;
        private System.Windows.Forms.TextBox tb_withdraw;
        private System.Windows.Forms.Button btn_withdraw;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn_logout3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lb_balance2;
    }
}

