﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Take_Home_Week_3_Rayna_Shera_Chang
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();                      
        }
        
        int jmlhAkun = 0;
        int akunKe = 0;
        List<string> listusername = new List<string>();
        List<string> listpass = new List<string>();
        List<int> listbalance = new List<int>();
        CultureInfo culture = new CultureInfo("id-ID");
        

        private void btn_register_Click(object sender, EventArgs e)
        {
            //buka panel register
            panel_login.Visible = false;
            panel_register.Visible = true;
            panel_mainview.Visible = false;
            tb_username.Text = "";
            tb_password.Text = "";
        }

        private void btn_register2_Click(object sender, EventArgs e)
        {
            int matchedUsername = 0;
            foreach (var username in listusername)
            {
                if (tb_username2.Text == username)
                {
                    matchedUsername++;
                }            
            }
            if (matchedUsername != 0)
            {
                MessageBox.Show("Username has been used");
            }
            else if (tb_username2.Text =="" || tb_password2.Text =="")
            {
                MessageBox.Show("Please Insert Username and Password");              
            }
            else
            {
                MessageBox.Show("Register Successful");
                listusername.Add(tb_username2.Text);
                listpass.Add(tb_password2.Text);
                listbalance.Add(0);
                jmlhAkun++;
                panel_login.Visible = true;
                panel_register.Visible = false;
                tb_username.Text = "";
                tb_password.Text = "";
                tb_username2.Text = "";
                tb_password2.Text = "";
            }
            tb_username.Text = "";
            tb_password.Text = "";
            tb_username2.Text = "";
            tb_password2.Text = "";

        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            int validLogin = 0;
            foreach (var username in listusername)
            {
                if (tb_username.Text == username && tb_password.Text == listpass[listusername.IndexOf(username)])
                {
                    validLogin++;
                    akunKe = listusername.IndexOf(username);
                }   
            }         
            if (jmlhAkun == 0)
            {
                MessageBox.Show("Username and Password not Found!");
            }
            else if (tb_username.Text == "" || tb_password.Text == "")
            {
                MessageBox.Show("Please Insert Username and Password");
            }
            else if (validLogin != 0)
            {
                MessageBox.Show("Login Successful");
                panel_login.Visible = false;
                panel_mainview.Visible = true;
                tb_username.Text = "";
                tb_password.Text = "";
                lb_balance.Text = listbalance[akunKe].ToString("C", culture);
            }
            else 
            {
                MessageBox.Show("Please Insert Username and Password");
                
            }
            tb_username.Text = "";
            tb_password.Text = "";

        }
                        
        private void Form1_Load(object sender, EventArgs e)
        {
            panel_login.Visible = true;
            panel_register.Visible = false;
            panel_mainview.Visible = false;
            panel_deposit.Visible = false;
            panel_withdraw.Visible = false;          
        }

        private void btn_logoutmain_Click(object sender, EventArgs e)
        {
            //logout di main view
            MessageBox.Show("Log Out Berhasil");
            panel_mainview.Visible = false;
            panel_login.Visible = true;
            tb_username.Text = "";
            tb_password.Text = "";
        }
        private void btn_logout2_Click(object sender, EventArgs e)
        {
            //logout di deposit view
            MessageBox.Show("Log Out Berhasil");
            panel_deposit.Visible = false;
            panel_login.Visible = true;
            tb_username.Text = "";
            tb_password.Text = "";
        }
        private void btn_logout3_Click(object sender, EventArgs e)
        {
            //logout di withdraw view
            MessageBox.Show("Log Out Berhasil");
            panel_withdraw.Visible = false;
            panel_login.Visible = true;
            tb_username.Text = "";
            tb_password.Text = "";
        }

        private void btn_depositmain_Click(object sender, EventArgs e)
        {
            //buka panel deposit
            panel_deposit.Visible = true;
            panel_mainview.Visible = false;
            tb_deposit.Text = "";
        }

        private void btn_withdrawmain_Click(object sender, EventArgs e)
        {
            //buka panel withdraw
            panel_withdraw.Visible = true;
            panel_mainview.Visible = false;
            tb_withdraw.Text = "";

        }
        private void btn_deposit_Click(object sender, EventArgs e)
        {   
            //panel input deposit
            int deposit = Convert.ToInt32(tb_deposit.Text);           
            if (tb_deposit.Text == "")
            {
                MessageBox.Show("Please Input Deposit Amount");
                tb_deposit.Text = "";
                panel_deposit.Visible = false;
                panel_mainview.Visible = true;
            }
            else if (tb_deposit.Text == "0")
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
                panel_deposit.Visible = false;
                panel_mainview.Visible = true;
                tb_deposit.Text = "";              
            }
            else
            {
                MessageBox.Show("Succesfully Add Deposit");
                listbalance[akunKe] += deposit;
                panel_deposit.Visible = false;
                panel_mainview.Visible = true;
                tb_deposit.Text = "";
                lb_balance.Text = listbalance[akunKe].ToString("C", culture);
                lb_balance2.Text = listbalance[akunKe].ToString("C", culture);              
            }
           
        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {             
            //panel input withdraw
            int withdraw = Convert.ToInt32(tb_withdraw.Text);
            if (tb_withdraw.Text == "")
            {
                MessageBox.Show("Please Input Withdraw Amount");              
            }
            else if (tb_withdraw.Text == "0")
            {
                MessageBox.Show("Withdraw Amount Can't be Less Than 1");
            }
            else if(listbalance[akunKe] < withdraw)
            {
                MessageBox.Show("Withdraw Failed. Not Enough Balance.");
            }
            else
            {              
                MessageBox.Show("Succesfully Withdraw");              
                listbalance[akunKe] -= withdraw;
                lb_balance.Text = listbalance[akunKe].ToString("C", culture);
                lb_balance2.Text = listbalance[akunKe].ToString("C", culture);
                panel_withdraw.Visible = false;
                panel_mainview.Visible = true;
                tb_withdraw.Text = "";
            }
            panel_withdraw.Visible = false;
            panel_mainview.Visible = true;
            tb_withdraw.Text = "";
        }      
        
    }
}
