﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Take_Home_Week_4_Rayna_Shera_Chang
{
    public partial class Form1 : Form
    {        
        public Form1()
        {
            InitializeComponent();      
        }

        List<Team> listTeam = new List<Team>();
        private void Form1_Load(object sender, EventArgs e)
        {
            Team team1 = new Team("Chelsea", "England", "London");
            listTeam.Add(team1);
            Team team2 = new Team("PSG", "France", "Paris");
            listTeam.Add(team2);
            Team team3 = new Team("Manchester United", "England", "Manchester");
            listTeam.Add(team3);

            Player player1chelsea = new Player("Robert Sanchez", "01", "GK");
            team1.players.Add(player1chelsea);
            Player player2chelsea = new Player("Axel Disasi", "02", "DF");
            team1.players.Add(player2chelsea);
            Player player3chelsea = new Player("Thiago Silva", "06", "DF");
            team1.players.Add(player3chelsea);
            Player player4chelsea = new Player("Raheem Sterling", "07", "FW");
            team1.players.Add(player4chelsea);
            Player player5chelsea = new Player("Enzo Fernandez", "08", "MF");
            team1.players.Add(player5chelsea);
            Player player6chelsea = new Player("Nicolas Jackson", "15", "FW");
            team1.players.Add(player6chelsea);
            Player player7chelsea = new Player("Lucas Bergstrom", "47", "GK");
            team1.players.Add(player7chelsea);
            Player player8chelsea = new Player("Ben Chilwell", "21", "DF");
            team1.players.Add(player8chelsea);
            Player player9chelsea = new Player("Diego Moreira", "43", "FW");
            team1.players.Add(player9chelsea);
            Player player10chelsea = new Player("Wesley Fofana", "33", "DF");
            team1.players.Add(player10chelsea);
            Player player11chelsea = new Player("Lesley Ugochukwu", "16", "MF");
            team1.players.Add(player11chelsea);

            Player player1psg = new Player("Neymar Jr.", "10", "FW");
            team2.players.Add(player1psg);
            Player player2psg = new Player("Kylian Mbappe", "07", "FW");
            team2.players.Add(player2psg);
            Player player3psg = new Player("Manuel Ugarte", "04", "MF");
            team2.players.Add(player3psg);
            Player player4psg = new Player("Nuno Mendes", "25", "DF");
            team2.players.Add(player4psg);
            Player player5psg = new Player("Arnau Tenas", "80", "GK");
            team2.players.Add(player5psg);
            Player player6psg = new Player("Marco Asensio", "11", "MF");
            team2.players.Add(player6psg);
            Player player7psg = new Player("Lee Kang-in", "19", "MF");
            team2.players.Add(player7psg);
            Player player8psg = new Player("Lucas Beraldo", "35", "DF");
            team2.players.Add(player8psg);
            Player player9psg = new Player("Keylor Navas", "01", "GK");
            team2.players.Add(player9psg);
            Player player10psg = new Player("Layvin Kurzawa", "97", "DF");
            team2.players.Add(player10psg);
            Player player11psg = new Player("Alexandre Letellier", "30", "GK");
            team2.players.Add(player11psg);

            Player player1MU = new Player("Sofyan Amrabat", "04", "MF");
            team3.players.Add(player1MU);
            Player player2MU = new Player("Diogo Dalot", "20", "DF");
            team3.players.Add(player2MU);
            Player player3MU = new Player("Altay Bayındır", "01", "GK");
            team3.players.Add(player3MU);
            Player player4MU = new Player("Kobbie Mainoo", "37", "MF");
            team3.players.Add(player4MU);
            Player player5MU = new Player("Tyrell Malacia", "12", "DF");
            team3.players.Add(player5MU);
            Player player6MU = new Player("Tom Heaton", "22", "GK");
            team3.players.Add(player6MU);
            Player player7MU = new Player("Christian Eriksen", "14", "MF");
            team3.players.Add(player7MU);
            Player player8MU = new Player("Anthony Martial", "09", "FW");
            team3.players.Add(player8MU);
            Player player9MU = new Player("Amad Diallo", "16", "MF");
            team3.players.Add(player9MU);
            Player player10MU = new Player("Bruno Fernandes", "08", "MF");
            team3.players.Add(player10MU);
            Player player11MU = new Player("Harry Maguire", "05", "DF");
            team3.players.Add(player11MU);

            cb_playerposition.Items.Add("GK");
            cb_playerposition.Items.Add("DF");
            cb_playerposition.Items.Add("MF");
            cb_playerposition.Items.Add("FW");
        }

        private void addplayer()
        {
            Player player1 = new Player(tb_PName.Text,tb_PNumber.Text,cb_playerposition.Text);
            bool samanama = true;
            bool samanomor = true;
            foreach(Team team in listTeam)
            {
                if(cb_team.Text ==team.teamname)
                {
                    foreach(Player player in team.players)
                    {
                        if(player1.playername ==player.playername)
                        {
                            samanama = false;
                            break;
                        }
                        else if(player1.playernum == player.playernum)
                        {
                            samanomor =false;
                            break;
                        }

                    }
                    if(samanama== true && samanomor ==true)
                    {
                        team.players.Add(player1);
                        lbox_all.Items.Clear();
                        foreach (Team currentTeam in listTeam)
                        {
                            if(currentTeam.teamname == cb_team.Text && currentTeam.teamcountry == cb_country.Text)
                            {
                                foreach (Player player in currentTeam.players)
                                {
                                    lbox_all.Items.Add("(" + player.playernum + ") " + player.playername + ", " + player.playerpos);
                                    lbox_all.Sorted = true;
                                }
                                break;
                            }
                        }
                    }
                    if(samanama ==false)
                    {
                        MessageBox.Show("Player with Same Name is found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (samanomor == false)
                    {
                        MessageBox.Show("Player with Same Number is found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        private void btn_addteam_Click(object sender, EventArgs e)
        {
            bool cekteam = false;
            foreach (Team team in listTeam)
            {
                if (team.teamname == tb_TName.Text)
                {
                    cekteam = true;
                    break;
                }
            }

            if (tb_TName.Text == "" || tb_TCountry.Text == "" || tb_TCity.Text == "")
            {
                MessageBox.Show("All of The Fields Need To Be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (cekteam)
            {
                MessageBox.Show("Team Already Exist!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Team Team = new Team(tb_TName.Text, tb_TCountry.Text, tb_TCity.Text);
                listTeam.Add(Team);
                foreach (Team country in listTeam)
                {
                    if (!cb_country.Items.Contains(country.teamcountry))
                    {
                        cb_country.Items.Add(country.teamcountry);
                    }
                }

                foreach (Team team in listTeam)
                {
                    if (!cb_team.Items.Contains(team.teamname) && (team.teamcountry == cb_country.Text))
                    {
                        cb_team.Items.Add(team.teamname);
                    }
                }
                tb_TName.Text = "";
                tb_TCountry.Text = "";
                tb_TCity.Text = "";
            }
            
            tb_TName.Text = "";
            tb_TCountry.Text = "";
            tb_TCity.Text = "";
        }

        private void btn_addplayer_Click(object sender, EventArgs e)
        {
            if (tb_PName.Text == "" || tb_PNumber.Text == "" || cb_playerposition.SelectedIndex == -1)
            {
                MessageBox.Show("All of The Fields Need To Be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_PName.Text = "";
                tb_PNumber.Text = "";
                cb_playerposition.SelectedIndex = -1;
            }
            else
            {
                addplayer();
                
            }
            cb_playerposition.SelectedIndex = -1;
            tb_PName.Text = "";
            tb_PNumber.Text = "";
            lbox_all.Sorted = true;
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if(lbox_all.Items.Count < 12)
            {
                MessageBox.Show("Unable to Remove Players if Players less than or equal to 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                for(int i = 0;i<listTeam.Count;i++)
                {
                    Team currentTeam = listTeam[i];
                    if(currentTeam.teamname == cb_team.Text)
                    {
                        for(int j=0;j<currentTeam.players.Count; j++)
                        {
                            Player currentPlayer = currentTeam.players[j];
                            if(lbox_all.SelectedItem.ToString().Contains(currentPlayer.playername))
                            {
                                currentTeam.players.RemoveAt(j);
                                break;
                            }
                        }
                    }
                }
                lbox_all.Items.RemoveAt(lbox_all.SelectedIndex);
            }
        }

        private void cb_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_team.Items.Clear();
            lbox_all.Items.Clear();
            foreach (Team b in listTeam)
            {
                if (b.teamcountry == cb_country.SelectedItem.ToString())
                {
                    cb_team.Items.Add(b.teamname);
                }
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbox_all.Items.Clear();
            foreach (Team teammm in listTeam)
            {
                if (teammm.teamname == cb_team.SelectedItem.ToString())
                {
                    foreach (Player players in teammm.players)
                    {
                        lbox_all.Items.Add("(" + players.playernum + ") " + players.playername + ", " + players.playerpos);
                    }
                }
            }
            lbox_all.Sorted = true;
        }
    }
}
