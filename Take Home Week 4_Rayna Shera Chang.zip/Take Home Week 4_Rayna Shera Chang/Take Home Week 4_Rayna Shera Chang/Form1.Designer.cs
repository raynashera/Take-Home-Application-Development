﻿namespace Take_Home_Week_4_Rayna_Shera_Chang
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cb_country = new System.Windows.Forms.ComboBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.lbox_all = new System.Windows.Forms.ListBox();
            this.btn_remove = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tb_TName = new System.Windows.Forms.TextBox();
            this.tb_TCity = new System.Windows.Forms.TextBox();
            this.tb_TCountry = new System.Windows.Forms.TextBox();
            this.tb_PNumber = new System.Windows.Forms.TextBox();
            this.tb_PName = new System.Windows.Forms.TextBox();
            this.cb_playerposition = new System.Windows.Forms.ComboBox();
            this.btn_addteam = new System.Windows.Forms.Button();
            this.btn_addplayer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Soccer Team List";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Choose Country:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Choose Team:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(845, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Adding Players";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(520, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Adding Team";
            // 
            // cb_country
            // 
            this.cb_country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_country.FormattingEnabled = true;
            this.cb_country.Items.AddRange(new object[] {
            "England",
            "France"});
            this.cb_country.Location = new System.Drawing.Point(179, 106);
            this.cb_country.Name = "cb_country";
            this.cb_country.Size = new System.Drawing.Size(156, 28);
            this.cb_country.TabIndex = 6;
            this.cb_country.SelectedIndexChanged += new System.EventHandler(this.cb_country_SelectedIndexChanged);
            // 
            // cb_team
            // 
            this.cb_team.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(179, 157);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(156, 28);
            this.cb_team.TabIndex = 7;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // lbox_all
            // 
            this.lbox_all.FormattingEnabled = true;
            this.lbox_all.ItemHeight = 20;
            this.lbox_all.Location = new System.Drawing.Point(38, 214);
            this.lbox_all.Name = "lbox_all";
            this.lbox_all.Size = new System.Drawing.Size(297, 164);
            this.lbox_all.TabIndex = 8;
            // 
            // btn_remove
            // 
            this.btn_remove.Location = new System.Drawing.Point(38, 385);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(108, 32);
            this.btn_remove.TabIndex = 9;
            this.btn_remove.Text = "Remove";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(384, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Team Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(384, 163);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "Team Country:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(384, 214);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 20);
            this.label8.TabIndex = 12;
            this.label8.Text = "Team City:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(715, 160);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 20);
            this.label9.TabIndex = 15;
            this.label9.Text = "Player Number:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(715, 214);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 20);
            this.label10.TabIndex = 14;
            this.label10.Text = "Player Position:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(715, 106);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 20);
            this.label11.TabIndex = 13;
            this.label11.Text = "Player Name:";
            // 
            // tb_TName
            // 
            this.tb_TName.Location = new System.Drawing.Point(524, 106);
            this.tb_TName.Name = "tb_TName";
            this.tb_TName.Size = new System.Drawing.Size(158, 26);
            this.tb_TName.TabIndex = 16;
            // 
            // tb_TCity
            // 
            this.tb_TCity.Location = new System.Drawing.Point(524, 211);
            this.tb_TCity.Name = "tb_TCity";
            this.tb_TCity.Size = new System.Drawing.Size(158, 26);
            this.tb_TCity.TabIndex = 17;
            // 
            // tb_TCountry
            // 
            this.tb_TCountry.Location = new System.Drawing.Point(524, 157);
            this.tb_TCountry.Name = "tb_TCountry";
            this.tb_TCountry.Size = new System.Drawing.Size(158, 26);
            this.tb_TCountry.TabIndex = 18;
            // 
            // tb_PNumber
            // 
            this.tb_PNumber.Location = new System.Drawing.Point(849, 156);
            this.tb_PNumber.Name = "tb_PNumber";
            this.tb_PNumber.Size = new System.Drawing.Size(156, 26);
            this.tb_PNumber.TabIndex = 20;
            // 
            // tb_PName
            // 
            this.tb_PName.Location = new System.Drawing.Point(849, 105);
            this.tb_PName.Name = "tb_PName";
            this.tb_PName.Size = new System.Drawing.Size(156, 26);
            this.tb_PName.TabIndex = 19;
            // 
            // cb_playerposition
            // 
            this.cb_playerposition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_playerposition.FormattingEnabled = true;
            this.cb_playerposition.Location = new System.Drawing.Point(849, 209);
            this.cb_playerposition.Name = "cb_playerposition";
            this.cb_playerposition.Size = new System.Drawing.Size(156, 28);
            this.cb_playerposition.TabIndex = 21;
            // 
            // btn_addteam
            // 
            this.btn_addteam.Location = new System.Drawing.Point(524, 257);
            this.btn_addteam.Name = "btn_addteam";
            this.btn_addteam.Size = new System.Drawing.Size(74, 32);
            this.btn_addteam.TabIndex = 22;
            this.btn_addteam.Text = "Add";
            this.btn_addteam.UseVisualStyleBackColor = true;
            this.btn_addteam.Click += new System.EventHandler(this.btn_addteam_Click);
            // 
            // btn_addplayer
            // 
            this.btn_addplayer.Location = new System.Drawing.Point(849, 257);
            this.btn_addplayer.Name = "btn_addplayer";
            this.btn_addplayer.Size = new System.Drawing.Size(74, 32);
            this.btn_addplayer.TabIndex = 23;
            this.btn_addplayer.Text = "Add";
            this.btn_addplayer.UseVisualStyleBackColor = true;
            this.btn_addplayer.Click += new System.EventHandler(this.btn_addplayer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1058, 471);
            this.Controls.Add(this.btn_addplayer);
            this.Controls.Add(this.btn_addteam);
            this.Controls.Add(this.cb_playerposition);
            this.Controls.Add(this.tb_PNumber);
            this.Controls.Add(this.tb_PName);
            this.Controls.Add(this.tb_TCountry);
            this.Controls.Add(this.tb_TCity);
            this.Controls.Add(this.tb_TName);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.lbox_all);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.cb_country);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cb_country;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.ListBox lbox_all;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tb_TName;
        private System.Windows.Forms.TextBox tb_TCity;
        private System.Windows.Forms.TextBox tb_TCountry;
        private System.Windows.Forms.TextBox tb_PNumber;
        private System.Windows.Forms.TextBox tb_PName;
        private System.Windows.Forms.ComboBox cb_playerposition;
        private System.Windows.Forms.Button btn_addteam;
        private System.Windows.Forms.Button btn_addplayer;
    }
}

