﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Take_Home_Week_4_Rayna_Shera_Chang
{
    public class Team
    {
        public string teamName;
        public string teamCountry;
        public string teamCity;
        public List<Player> players = new List<Player>();

        public string teamname
        {
            get { return teamName; }
            set { teamName = value; }
        }

        public string teamcountry
        { 
            get { return teamCountry; } 
            set {  teamCountry = value; } 
        }

        public string teamcity
        {
            get { return teamCity; }
            set { teamCity = value; }
        }

        public Team(string teamname, string teamcountry, string teamcity)
        {
            this.teamname = teamname;
            this.teamcountry = teamcountry;
            this.teamcity = teamcity;
        }


    }
}
