﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Take_Home_Week_4_Rayna_Shera_Chang
{
    public class Player
    {
        public string playerName;
        public string playerNum;
        public string playerPos;

        public string playername
        {  
            get { return playerName; } 
            set {  playerName = value; } 
        }
        public string playernum
        { 
            get { return playerNum; } 
            set { playerNum = value; } 
        }
        public string playerpos
        { 
            get { return playerPos; } 
            set { playerPos = value; } 
        }

        public Player(string playername,string playernum,string playerpos)
        {
            this.playername = playername;
            this.playernum = playernum;
            this.playerpos = playerpos;
        }
        
    }
}
