﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Take_Home_Week_2
{
    public partial class Game_Guessr : Form
    {
        
        List<char> hurufbenar = new List<char>();
        public Game_Guessr()
        {
            InitializeComponent();
            lb_kataterpilih.Text = Form1.kataterpilih;
            foreach (char huruf in Form1.kataterpilih.ToUpper())
            {
                hurufbenar.Add(huruf);
            }
            lb_hurufbenar1.Text = hurufbenar[0].ToString();
            lb_hurufbenar2.Text = hurufbenar[1].ToString();
            lb_hurufbenar3.Text = hurufbenar[2].ToString();
            lb_hurufbenar4.Text = hurufbenar[3].ToString();
            lb_hurufbenar5.Text = hurufbenar[4].ToString();
        }
        public void tebakan(char pilihan)
        {
            int faktor = 0;
            for(int i=0;i<5;i++)
            {
                if(pilihan == hurufbenar[i])
                {
                    faktor = i;
                    if(faktor == 0)
                    {
                        lb_1.Visible = false;
                    }
                    else if (faktor == 1)
                    {
                        lb_2.Visible = false;
                    }
                    else if (faktor == 2)
                    {
                        lb_3.Visible = false;
                    }
                    else if (faktor == 3)
                    {
                        lb_4.Visible = false;
                    }
                    else if (faktor == 4)
                    {
                        lb_5.Visible = false;
                    }
                }
            }

            if (!lb_1.Visible && !lb_2.Visible&& !lb_3.Visible && !lb_4.Visible && !lb_5.Visible)
            {
                MessageBox.Show("Congratulations! You win!");
                this.Hide();
            }
        }

        private void btn_Q_Click(object sender, EventArgs e)
        {
            tebakan('Q');
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            tebakan('W');
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            tebakan('E');
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            tebakan('R');
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            tebakan('T');
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            tebakan('Y');
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            tebakan('U');
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            tebakan('I');
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            tebakan('O');
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            tebakan('P');
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            tebakan('A');
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            tebakan('S');
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            tebakan('D');
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            tebakan('F');
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            tebakan('G');
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            tebakan('H');
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            tebakan('J');
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            tebakan('K');
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            tebakan('L');
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            tebakan('Z');
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            tebakan('X');
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            tebakan('C');
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            tebakan('V');
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            tebakan('B');
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            tebakan('N');
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            tebakan('M');
        }
    }
}
