﻿namespace Take_Home_Week_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_word1 = new System.Windows.Forms.Label();
            this.lb_word2 = new System.Windows.Forms.Label();
            this.lb_word3 = new System.Windows.Forms.Label();
            this.lb_word4 = new System.Windows.Forms.Label();
            this.lb_word5 = new System.Windows.Forms.Label();
            this.tb_word1 = new System.Windows.Forms.TextBox();
            this.tb_word2 = new System.Windows.Forms.TextBox();
            this.tb_word3 = new System.Windows.Forms.TextBox();
            this.tb_word4 = new System.Windows.Forms.TextBox();
            this.tb_word5 = new System.Windows.Forms.TextBox();
            this.btn_play = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lb_word1
            // 
            this.lb_word1.AutoSize = true;
            this.lb_word1.Location = new System.Drawing.Point(332, 131);
            this.lb_word1.Name = "lb_word1";
            this.lb_word1.Size = new System.Drawing.Size(60, 20);
            this.lb_word1.TabIndex = 0;
            this.lb_word1.Text = "Word 1";
            // 
            // lb_word2
            // 
            this.lb_word2.AutoSize = true;
            this.lb_word2.Location = new System.Drawing.Point(332, 179);
            this.lb_word2.Name = "lb_word2";
            this.lb_word2.Size = new System.Drawing.Size(60, 20);
            this.lb_word2.TabIndex = 1;
            this.lb_word2.Text = "Word 2";
            // 
            // lb_word3
            // 
            this.lb_word3.AutoSize = true;
            this.lb_word3.Location = new System.Drawing.Point(332, 229);
            this.lb_word3.Name = "lb_word3";
            this.lb_word3.Size = new System.Drawing.Size(60, 20);
            this.lb_word3.TabIndex = 2;
            this.lb_word3.Text = "Word 3";
            // 
            // lb_word4
            // 
            this.lb_word4.AutoSize = true;
            this.lb_word4.Location = new System.Drawing.Point(332, 281);
            this.lb_word4.Name = "lb_word4";
            this.lb_word4.Size = new System.Drawing.Size(60, 20);
            this.lb_word4.TabIndex = 3;
            this.lb_word4.Text = "Word 4";
            // 
            // lb_word5
            // 
            this.lb_word5.AutoSize = true;
            this.lb_word5.Location = new System.Drawing.Point(332, 334);
            this.lb_word5.Name = "lb_word5";
            this.lb_word5.Size = new System.Drawing.Size(60, 20);
            this.lb_word5.TabIndex = 4;
            this.lb_word5.Text = "Word 5";
            // 
            // tb_word1
            // 
            this.tb_word1.Location = new System.Drawing.Point(429, 128);
            this.tb_word1.Name = "tb_word1";
            this.tb_word1.Size = new System.Drawing.Size(164, 26);
            this.tb_word1.TabIndex = 5;
            // 
            // tb_word2
            // 
            this.tb_word2.Location = new System.Drawing.Point(429, 176);
            this.tb_word2.Name = "tb_word2";
            this.tb_word2.Size = new System.Drawing.Size(164, 26);
            this.tb_word2.TabIndex = 6;
            // 
            // tb_word3
            // 
            this.tb_word3.Location = new System.Drawing.Point(429, 226);
            this.tb_word3.Name = "tb_word3";
            this.tb_word3.Size = new System.Drawing.Size(164, 26);
            this.tb_word3.TabIndex = 7;
            // 
            // tb_word4
            // 
            this.tb_word4.Location = new System.Drawing.Point(429, 278);
            this.tb_word4.Name = "tb_word4";
            this.tb_word4.Size = new System.Drawing.Size(164, 26);
            this.tb_word4.TabIndex = 8;
            // 
            // tb_word5
            // 
            this.tb_word5.Location = new System.Drawing.Point(429, 331);
            this.tb_word5.Name = "tb_word5";
            this.tb_word5.Size = new System.Drawing.Size(164, 26);
            this.tb_word5.TabIndex = 9;
            // 
            // btn_play
            // 
            this.btn_play.Location = new System.Drawing.Point(429, 386);
            this.btn_play.Name = "btn_play";
            this.btn_play.Size = new System.Drawing.Size(91, 32);
            this.btn_play.TabIndex = 10;
            this.btn_play.Text = "Play!";
            this.btn_play.UseVisualStyleBackColor = true;
            this.btn_play.Click += new System.EventHandler(this.btn_play_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(343, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(235, 35);
            this.label1.TabIndex = 11;
            this.label1.Text = "GAME GUESSR";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1015, 560);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_play);
            this.Controls.Add(this.tb_word5);
            this.Controls.Add(this.tb_word4);
            this.Controls.Add(this.tb_word3);
            this.Controls.Add(this.tb_word2);
            this.Controls.Add(this.tb_word1);
            this.Controls.Add(this.lb_word5);
            this.Controls.Add(this.lb_word4);
            this.Controls.Add(this.lb_word3);
            this.Controls.Add(this.lb_word2);
            this.Controls.Add(this.lb_word1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_word1;
        private System.Windows.Forms.Label lb_word2;
        private System.Windows.Forms.Label lb_word3;
        private System.Windows.Forms.Label lb_word4;
        private System.Windows.Forms.Label lb_word5;
        private System.Windows.Forms.TextBox tb_word1;
        private System.Windows.Forms.TextBox tb_word2;
        private System.Windows.Forms.TextBox tb_word3;
        private System.Windows.Forms.TextBox tb_word4;
        private System.Windows.Forms.TextBox tb_word5;
        private System.Windows.Forms.Button btn_play;
        private System.Windows.Forms.Label label1;
    }
}

