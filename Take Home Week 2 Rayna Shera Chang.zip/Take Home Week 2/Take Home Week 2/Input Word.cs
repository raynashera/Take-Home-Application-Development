﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Take_Home_Week_2
{
    public partial class Form1 : Form
    {
        public static string kataterpilih = "";
        public Form1()
        {
            InitializeComponent();
        }
        
        private void btn_play_Click(object sender, EventArgs e)
        {
            string word1 = Convert.ToString(tb_word1.Text);
            string word2 = Convert.ToString(tb_word2.Text);
            string word3 = Convert.ToString(tb_word3.Text);
            string word4 = Convert.ToString(tb_word4.Text);
            string word5 = Convert.ToString(tb_word5.Text);

            List<string> kumpulankata = new List<string>();        

            if(word1.Length==5 && word2.Length==5 && word3.Length==5 && word4.Length==5 && word5.Length==5)
            {
                kumpulankata.Add(word1);
                kumpulankata.Add(word2);
                kumpulankata.Add(word3);
                kumpulankata.Add(word4);
                kumpulankata.Add(word5);

                int kembar = 0;            
                foreach (var kata1 in kumpulankata)
                {
                    foreach (var kata2 in kumpulankata)
                    {
                        if (kata1 == kata2)
                        {
                            kembar++;
                        }
                    }
                }

                int number = 0;
                foreach (var kata in kumpulankata)
                {
                    if(kata.Any(Char.IsDigit))
                    {
                        number++;
                    }
                }                     
                if (number>=1)
                {
                    MessageBox.Show("An error has been found on the game! Please fix first!");
                }
                else if(kembar>=6)
                {
                    MessageBox.Show("An error has been found on the game! Please fix first!");
                }
                else
                {
                    MessageBox.Show("Let's Play!");
                    Random rnd = new Random();
                    int indeksterpilih = rnd.Next(0,5);
                    kataterpilih = kumpulankata[indeksterpilih];


                    Form Game_Guessr = new Game_Guessr();
                    Game_Guessr.Show();
                    this.Hide();
                }            
            }
            else
            {
                MessageBox.Show("An error has been found on the game! Please fix first!");
            }
        }
    }
}
