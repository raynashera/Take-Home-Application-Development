﻿namespace Take_Home_Week_2
{
    partial class Game_Guessr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Q = new System.Windows.Forms.Button();
            this.btn_W = new System.Windows.Forms.Button();
            this.btn_E = new System.Windows.Forms.Button();
            this.btn_R = new System.Windows.Forms.Button();
            this.btn_T = new System.Windows.Forms.Button();
            this.btn_Y = new System.Windows.Forms.Button();
            this.btn_U = new System.Windows.Forms.Button();
            this.btn_I = new System.Windows.Forms.Button();
            this.btn_O = new System.Windows.Forms.Button();
            this.btn_P = new System.Windows.Forms.Button();
            this.btn_L = new System.Windows.Forms.Button();
            this.btn_H = new System.Windows.Forms.Button();
            this.btn_J = new System.Windows.Forms.Button();
            this.btn_K = new System.Windows.Forms.Button();
            this.btn_D = new System.Windows.Forms.Button();
            this.btn_F = new System.Windows.Forms.Button();
            this.btn_G = new System.Windows.Forms.Button();
            this.btn_S = new System.Windows.Forms.Button();
            this.btn_A = new System.Windows.Forms.Button();
            this.btn_M = new System.Windows.Forms.Button();
            this.btn_V = new System.Windows.Forms.Button();
            this.btn_B = new System.Windows.Forms.Button();
            this.btn_N = new System.Windows.Forms.Button();
            this.btn_Z = new System.Windows.Forms.Button();
            this.btn_X = new System.Windows.Forms.Button();
            this.btn_C = new System.Windows.Forms.Button();
            this.lb_1 = new System.Windows.Forms.Label();
            this.lb_2 = new System.Windows.Forms.Label();
            this.lb_3 = new System.Windows.Forms.Label();
            this.lb_4 = new System.Windows.Forms.Label();
            this.lb_5 = new System.Windows.Forms.Label();
            this.lb_hurufbenar5 = new System.Windows.Forms.Label();
            this.lb_hurufbenar4 = new System.Windows.Forms.Label();
            this.lb_hurufbenar3 = new System.Windows.Forms.Label();
            this.lb_hurufbenar2 = new System.Windows.Forms.Label();
            this.lb_hurufbenar1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_kataterpilih = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Q
            // 
            this.btn_Q.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Q.Location = new System.Drawing.Point(72, 189);
            this.btn_Q.Name = "btn_Q";
            this.btn_Q.Size = new System.Drawing.Size(70, 70);
            this.btn_Q.TabIndex = 0;
            this.btn_Q.Text = "Q";
            this.btn_Q.UseVisualStyleBackColor = true;
            this.btn_Q.Click += new System.EventHandler(this.btn_Q_Click);
            // 
            // btn_W
            // 
            this.btn_W.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_W.Location = new System.Drawing.Point(148, 189);
            this.btn_W.Name = "btn_W";
            this.btn_W.Size = new System.Drawing.Size(70, 70);
            this.btn_W.TabIndex = 1;
            this.btn_W.Text = "W";
            this.btn_W.UseVisualStyleBackColor = true;
            this.btn_W.Click += new System.EventHandler(this.btn_W_Click);
            // 
            // btn_E
            // 
            this.btn_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_E.Location = new System.Drawing.Point(224, 189);
            this.btn_E.Name = "btn_E";
            this.btn_E.Size = new System.Drawing.Size(70, 70);
            this.btn_E.TabIndex = 2;
            this.btn_E.Text = "E";
            this.btn_E.UseVisualStyleBackColor = true;
            this.btn_E.Click += new System.EventHandler(this.btn_E_Click);
            // 
            // btn_R
            // 
            this.btn_R.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_R.Location = new System.Drawing.Point(300, 189);
            this.btn_R.Name = "btn_R";
            this.btn_R.Size = new System.Drawing.Size(70, 70);
            this.btn_R.TabIndex = 5;
            this.btn_R.Text = "R";
            this.btn_R.UseVisualStyleBackColor = true;
            this.btn_R.Click += new System.EventHandler(this.btn_R_Click);
            // 
            // btn_T
            // 
            this.btn_T.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_T.Location = new System.Drawing.Point(376, 189);
            this.btn_T.Name = "btn_T";
            this.btn_T.Size = new System.Drawing.Size(70, 70);
            this.btn_T.TabIndex = 4;
            this.btn_T.Text = "T";
            this.btn_T.UseVisualStyleBackColor = true;
            this.btn_T.Click += new System.EventHandler(this.btn_T_Click);
            // 
            // btn_Y
            // 
            this.btn_Y.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Y.Location = new System.Drawing.Point(452, 189);
            this.btn_Y.Name = "btn_Y";
            this.btn_Y.Size = new System.Drawing.Size(70, 70);
            this.btn_Y.TabIndex = 3;
            this.btn_Y.Text = "Y";
            this.btn_Y.UseVisualStyleBackColor = true;
            this.btn_Y.Click += new System.EventHandler(this.btn_Y_Click);
            // 
            // btn_U
            // 
            this.btn_U.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_U.Location = new System.Drawing.Point(528, 189);
            this.btn_U.Name = "btn_U";
            this.btn_U.Size = new System.Drawing.Size(70, 70);
            this.btn_U.TabIndex = 8;
            this.btn_U.Text = "U";
            this.btn_U.UseVisualStyleBackColor = true;
            this.btn_U.Click += new System.EventHandler(this.btn_U_Click);
            // 
            // btn_I
            // 
            this.btn_I.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_I.Location = new System.Drawing.Point(604, 189);
            this.btn_I.Name = "btn_I";
            this.btn_I.Size = new System.Drawing.Size(70, 70);
            this.btn_I.TabIndex = 7;
            this.btn_I.Text = "I";
            this.btn_I.UseVisualStyleBackColor = true;
            this.btn_I.Click += new System.EventHandler(this.btn_I_Click);
            // 
            // btn_O
            // 
            this.btn_O.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_O.Location = new System.Drawing.Point(680, 189);
            this.btn_O.Name = "btn_O";
            this.btn_O.Size = new System.Drawing.Size(70, 70);
            this.btn_O.TabIndex = 6;
            this.btn_O.Text = "O";
            this.btn_O.UseVisualStyleBackColor = true;
            this.btn_O.Click += new System.EventHandler(this.btn_O_Click);
            // 
            // btn_P
            // 
            this.btn_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_P.Location = new System.Drawing.Point(756, 189);
            this.btn_P.Name = "btn_P";
            this.btn_P.Size = new System.Drawing.Size(70, 70);
            this.btn_P.TabIndex = 9;
            this.btn_P.Text = "P";
            this.btn_P.UseVisualStyleBackColor = true;
            this.btn_P.Click += new System.EventHandler(this.btn_P_Click);
            // 
            // btn_L
            // 
            this.btn_L.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_L.Location = new System.Drawing.Point(718, 265);
            this.btn_L.Name = "btn_L";
            this.btn_L.Size = new System.Drawing.Size(70, 70);
            this.btn_L.TabIndex = 18;
            this.btn_L.Text = "L";
            this.btn_L.UseVisualStyleBackColor = true;
            this.btn_L.Click += new System.EventHandler(this.btn_L_Click);
            // 
            // btn_H
            // 
            this.btn_H.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_H.Location = new System.Drawing.Point(490, 265);
            this.btn_H.Name = "btn_H";
            this.btn_H.Size = new System.Drawing.Size(70, 70);
            this.btn_H.TabIndex = 17;
            this.btn_H.Text = "H";
            this.btn_H.UseVisualStyleBackColor = true;
            this.btn_H.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_J
            // 
            this.btn_J.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_J.Location = new System.Drawing.Point(566, 265);
            this.btn_J.Name = "btn_J";
            this.btn_J.Size = new System.Drawing.Size(70, 70);
            this.btn_J.TabIndex = 16;
            this.btn_J.Text = "J";
            this.btn_J.UseVisualStyleBackColor = true;
            this.btn_J.Click += new System.EventHandler(this.btn_J_Click);
            // 
            // btn_K
            // 
            this.btn_K.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_K.Location = new System.Drawing.Point(642, 265);
            this.btn_K.Name = "btn_K";
            this.btn_K.Size = new System.Drawing.Size(70, 70);
            this.btn_K.TabIndex = 15;
            this.btn_K.Text = "K";
            this.btn_K.UseVisualStyleBackColor = true;
            this.btn_K.Click += new System.EventHandler(this.btn_K_Click);
            // 
            // btn_D
            // 
            this.btn_D.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_D.Location = new System.Drawing.Point(262, 265);
            this.btn_D.Name = "btn_D";
            this.btn_D.Size = new System.Drawing.Size(70, 70);
            this.btn_D.TabIndex = 14;
            this.btn_D.Text = "D";
            this.btn_D.UseVisualStyleBackColor = true;
            this.btn_D.Click += new System.EventHandler(this.btn_D_Click);
            // 
            // btn_F
            // 
            this.btn_F.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_F.Location = new System.Drawing.Point(338, 265);
            this.btn_F.Name = "btn_F";
            this.btn_F.Size = new System.Drawing.Size(70, 70);
            this.btn_F.TabIndex = 13;
            this.btn_F.Text = "F";
            this.btn_F.UseVisualStyleBackColor = true;
            this.btn_F.Click += new System.EventHandler(this.btn_F_Click);
            // 
            // btn_G
            // 
            this.btn_G.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_G.Location = new System.Drawing.Point(414, 265);
            this.btn_G.Name = "btn_G";
            this.btn_G.Size = new System.Drawing.Size(70, 70);
            this.btn_G.TabIndex = 12;
            this.btn_G.Text = "G";
            this.btn_G.UseVisualStyleBackColor = true;
            this.btn_G.Click += new System.EventHandler(this.btn_G_Click);
            // 
            // btn_S
            // 
            this.btn_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_S.Location = new System.Drawing.Point(186, 265);
            this.btn_S.Name = "btn_S";
            this.btn_S.Size = new System.Drawing.Size(70, 70);
            this.btn_S.TabIndex = 11;
            this.btn_S.Text = "S";
            this.btn_S.UseVisualStyleBackColor = true;
            this.btn_S.Click += new System.EventHandler(this.btn_S_Click);
            // 
            // btn_A
            // 
            this.btn_A.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_A.Location = new System.Drawing.Point(110, 265);
            this.btn_A.Name = "btn_A";
            this.btn_A.Size = new System.Drawing.Size(70, 70);
            this.btn_A.TabIndex = 10;
            this.btn_A.Text = "A";
            this.btn_A.UseVisualStyleBackColor = true;
            this.btn_A.Click += new System.EventHandler(this.btn_A_Click);
            // 
            // btn_M
            // 
            this.btn_M.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_M.Location = new System.Drawing.Point(642, 341);
            this.btn_M.Name = "btn_M";
            this.btn_M.Size = new System.Drawing.Size(70, 70);
            this.btn_M.TabIndex = 25;
            this.btn_M.Text = "M";
            this.btn_M.UseVisualStyleBackColor = true;
            this.btn_M.Click += new System.EventHandler(this.btn_M_Click);
            // 
            // btn_V
            // 
            this.btn_V.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_V.Location = new System.Drawing.Point(414, 341);
            this.btn_V.Name = "btn_V";
            this.btn_V.Size = new System.Drawing.Size(70, 70);
            this.btn_V.TabIndex = 24;
            this.btn_V.Text = "V";
            this.btn_V.UseVisualStyleBackColor = true;
            this.btn_V.Click += new System.EventHandler(this.btn_V_Click);
            // 
            // btn_B
            // 
            this.btn_B.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_B.Location = new System.Drawing.Point(490, 341);
            this.btn_B.Name = "btn_B";
            this.btn_B.Size = new System.Drawing.Size(70, 70);
            this.btn_B.TabIndex = 23;
            this.btn_B.Text = "B";
            this.btn_B.UseVisualStyleBackColor = true;
            this.btn_B.Click += new System.EventHandler(this.btn_B_Click);
            // 
            // btn_N
            // 
            this.btn_N.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_N.Location = new System.Drawing.Point(566, 341);
            this.btn_N.Name = "btn_N";
            this.btn_N.Size = new System.Drawing.Size(70, 70);
            this.btn_N.TabIndex = 22;
            this.btn_N.Text = "N";
            this.btn_N.UseVisualStyleBackColor = true;
            this.btn_N.Click += new System.EventHandler(this.btn_N_Click);
            // 
            // btn_Z
            // 
            this.btn_Z.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Z.Location = new System.Drawing.Point(186, 341);
            this.btn_Z.Name = "btn_Z";
            this.btn_Z.Size = new System.Drawing.Size(70, 70);
            this.btn_Z.TabIndex = 21;
            this.btn_Z.Text = "Z";
            this.btn_Z.UseVisualStyleBackColor = true;
            this.btn_Z.Click += new System.EventHandler(this.btn_Z_Click);
            // 
            // btn_X
            // 
            this.btn_X.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_X.Location = new System.Drawing.Point(262, 341);
            this.btn_X.Name = "btn_X";
            this.btn_X.Size = new System.Drawing.Size(70, 70);
            this.btn_X.TabIndex = 20;
            this.btn_X.Text = "X";
            this.btn_X.UseVisualStyleBackColor = true;
            this.btn_X.Click += new System.EventHandler(this.btn_X_Click);
            // 
            // btn_C
            // 
            this.btn_C.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_C.Location = new System.Drawing.Point(338, 341);
            this.btn_C.Name = "btn_C";
            this.btn_C.Size = new System.Drawing.Size(70, 70);
            this.btn_C.TabIndex = 19;
            this.btn_C.Text = "C";
            this.btn_C.UseVisualStyleBackColor = true;
            this.btn_C.Click += new System.EventHandler(this.btn_C_Click);
            // 
            // lb_1
            // 
            this.lb_1.AutoSize = true;
            this.lb_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_1.Location = new System.Drawing.Point(286, 95);
            this.lb_1.Name = "lb_1";
            this.lb_1.Size = new System.Drawing.Size(46, 52);
            this.lb_1.TabIndex = 26;
            this.lb_1.Text = "_";
            // 
            // lb_2
            // 
            this.lb_2.AutoSize = true;
            this.lb_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_2.Location = new System.Drawing.Point(350, 95);
            this.lb_2.Name = "lb_2";
            this.lb_2.Size = new System.Drawing.Size(46, 52);
            this.lb_2.TabIndex = 27;
            this.lb_2.Text = "_";
            // 
            // lb_3
            // 
            this.lb_3.AutoSize = true;
            this.lb_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_3.Location = new System.Drawing.Point(414, 95);
            this.lb_3.Name = "lb_3";
            this.lb_3.Size = new System.Drawing.Size(46, 52);
            this.lb_3.TabIndex = 28;
            this.lb_3.Text = "_";
            // 
            // lb_4
            // 
            this.lb_4.AutoSize = true;
            this.lb_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_4.Location = new System.Drawing.Point(478, 95);
            this.lb_4.Name = "lb_4";
            this.lb_4.Size = new System.Drawing.Size(46, 52);
            this.lb_4.TabIndex = 29;
            this.lb_4.Text = "_";
            // 
            // lb_5
            // 
            this.lb_5.AutoSize = true;
            this.lb_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_5.Location = new System.Drawing.Point(542, 95);
            this.lb_5.Name = "lb_5";
            this.lb_5.Size = new System.Drawing.Size(46, 52);
            this.lb_5.TabIndex = 30;
            this.lb_5.Text = "_";
            // 
            // lb_hurufbenar5
            // 
            this.lb_hurufbenar5.AutoSize = true;
            this.lb_hurufbenar5.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_hurufbenar5.Location = new System.Drawing.Point(542, 95);
            this.lb_hurufbenar5.Name = "lb_hurufbenar5";
            this.lb_hurufbenar5.Size = new System.Drawing.Size(46, 52);
            this.lb_hurufbenar5.TabIndex = 35;
            this.lb_hurufbenar5.Text = "?";
            // 
            // lb_hurufbenar4
            // 
            this.lb_hurufbenar4.AutoSize = true;
            this.lb_hurufbenar4.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_hurufbenar4.Location = new System.Drawing.Point(478, 95);
            this.lb_hurufbenar4.Name = "lb_hurufbenar4";
            this.lb_hurufbenar4.Size = new System.Drawing.Size(46, 52);
            this.lb_hurufbenar4.TabIndex = 34;
            this.lb_hurufbenar4.Text = "?";
            // 
            // lb_hurufbenar3
            // 
            this.lb_hurufbenar3.AutoSize = true;
            this.lb_hurufbenar3.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_hurufbenar3.Location = new System.Drawing.Point(414, 95);
            this.lb_hurufbenar3.Name = "lb_hurufbenar3";
            this.lb_hurufbenar3.Size = new System.Drawing.Size(46, 52);
            this.lb_hurufbenar3.TabIndex = 33;
            this.lb_hurufbenar3.Text = "?";
            // 
            // lb_hurufbenar2
            // 
            this.lb_hurufbenar2.AutoSize = true;
            this.lb_hurufbenar2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_hurufbenar2.Location = new System.Drawing.Point(350, 95);
            this.lb_hurufbenar2.Name = "lb_hurufbenar2";
            this.lb_hurufbenar2.Size = new System.Drawing.Size(46, 52);
            this.lb_hurufbenar2.TabIndex = 32;
            this.lb_hurufbenar2.Text = "?";
            // 
            // lb_hurufbenar1
            // 
            this.lb_hurufbenar1.AutoSize = true;
            this.lb_hurufbenar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_hurufbenar1.Location = new System.Drawing.Point(286, 95);
            this.lb_hurufbenar1.Name = "lb_hurufbenar1";
            this.lb_hurufbenar1.Size = new System.Drawing.Size(46, 52);
            this.lb_hurufbenar1.TabIndex = 31;
            this.lb_hurufbenar1.Text = "?";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("OCR A Extended", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(314, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 25);
            this.label1.TabIndex = 36;
            this.label1.Text = "GUESS THE WORD!";
            // 
            // lb_kataterpilih
            // 
            this.lb_kataterpilih.AutoSize = true;
            this.lb_kataterpilih.Location = new System.Drawing.Point(714, 54);
            this.lb_kataterpilih.Name = "lb_kataterpilih";
            this.lb_kataterpilih.Size = new System.Drawing.Size(86, 20);
            this.lb_kataterpilih.TabIndex = 37;
            this.lb_kataterpilih.Text = "kataterpilih";
            // 
            // Game_Guessr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(896, 487);
            this.Controls.Add(this.lb_kataterpilih);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_5);
            this.Controls.Add(this.lb_4);
            this.Controls.Add(this.lb_3);
            this.Controls.Add(this.lb_2);
            this.Controls.Add(this.lb_1);
            this.Controls.Add(this.btn_M);
            this.Controls.Add(this.btn_V);
            this.Controls.Add(this.btn_B);
            this.Controls.Add(this.btn_N);
            this.Controls.Add(this.btn_Z);
            this.Controls.Add(this.btn_X);
            this.Controls.Add(this.btn_C);
            this.Controls.Add(this.btn_L);
            this.Controls.Add(this.btn_H);
            this.Controls.Add(this.btn_J);
            this.Controls.Add(this.btn_K);
            this.Controls.Add(this.btn_D);
            this.Controls.Add(this.btn_F);
            this.Controls.Add(this.btn_G);
            this.Controls.Add(this.btn_S);
            this.Controls.Add(this.btn_A);
            this.Controls.Add(this.btn_P);
            this.Controls.Add(this.btn_U);
            this.Controls.Add(this.btn_I);
            this.Controls.Add(this.btn_O);
            this.Controls.Add(this.btn_R);
            this.Controls.Add(this.btn_T);
            this.Controls.Add(this.btn_Y);
            this.Controls.Add(this.btn_E);
            this.Controls.Add(this.btn_W);
            this.Controls.Add(this.btn_Q);
            this.Controls.Add(this.lb_hurufbenar5);
            this.Controls.Add(this.lb_hurufbenar4);
            this.Controls.Add(this.lb_hurufbenar3);
            this.Controls.Add(this.lb_hurufbenar2);
            this.Controls.Add(this.lb_hurufbenar1);
            this.Name = "Game_Guessr";
            this.Text = "Game_Guessr";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_W;
        private System.Windows.Forms.Button btn_E;
        private System.Windows.Forms.Button btn_R;
        private System.Windows.Forms.Button btn_T;
        private System.Windows.Forms.Button btn_Y;
        private System.Windows.Forms.Button btn_U;
        private System.Windows.Forms.Button btn_I;
        private System.Windows.Forms.Button btn_O;
        private System.Windows.Forms.Button btn_P;
        private System.Windows.Forms.Button btn_Q;
        private System.Windows.Forms.Button btn_L;
        private System.Windows.Forms.Button btn_H;
        private System.Windows.Forms.Button btn_J;
        private System.Windows.Forms.Button btn_K;
        private System.Windows.Forms.Button btn_D;
        private System.Windows.Forms.Button btn_F;
        private System.Windows.Forms.Button btn_G;
        private System.Windows.Forms.Button btn_S;
        private System.Windows.Forms.Button btn_A;
        private System.Windows.Forms.Button btn_M;
        private System.Windows.Forms.Button btn_V;
        private System.Windows.Forms.Button btn_B;
        private System.Windows.Forms.Button btn_N;
        private System.Windows.Forms.Button btn_Z;
        private System.Windows.Forms.Button btn_X;
        private System.Windows.Forms.Button btn_C;
        private System.Windows.Forms.Label lb_1;
        private System.Windows.Forms.Label lb_2;
        private System.Windows.Forms.Label lb_3;
        private System.Windows.Forms.Label lb_4;
        private System.Windows.Forms.Label lb_5;
        private System.Windows.Forms.Label lb_hurufbenar5;
        private System.Windows.Forms.Label lb_hurufbenar4;
        private System.Windows.Forms.Label lb_hurufbenar3;
        private System.Windows.Forms.Label lb_hurufbenar2;
        private System.Windows.Forms.Label lb_hurufbenar1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_kataterpilih;
    }
}