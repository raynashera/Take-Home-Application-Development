﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Take_Home_Week_9_Rayna_Shera_Chang
{
    public partial class Form1 : Form
    {
        DataTable dtCart; 
        OpenFileDialog ofd = new OpenFileDialog();
        int cek;
        int quantity = 0;
        int price;
        int total;
        int subTotalprice = 0;
        int totalprice;
        string pilih = "";

        public Form1()
        {
            InitializeComponent();
            tBox_itemprice.KeyPress += tBox_itemprice_KeyPress;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtCart = new DataTable();
            dtCart.Columns.Add("Item Name");
            dtCart.Columns.Add("Quantity");
            dtCart.Columns.Add("Price");
            dtCart.Columns.Add("Total");

            dgv1.DataSource = dtCart;

            pnl_tshirt.Visible = false;
            pnl_shirt.Visible = false;
            pnl_pants.Visible = false;
            pnl_longpants.Visible = false;
            pnl_shoes.Visible = false;
            pnl_jewelleries.Visible = false;
            pnl_others.Visible = false;
        }

        private void defaultPanel()
        {
            pnl_tshirt.Visible = false;
            pnl_shirt.Visible = false;
            pnl_pants.Visible = false;
            pnl_longpants.Visible = false;  
            pnl_shoes.Visible = false;
            pnl_jewelleries.Visible = false;
            pnl_others.Visible = false;
        }

        private void defaultVisible()
        {
            lb_nama1.Visible = true;
            lb_nama2.Visible = true;
            lb_nama3.Visible = true;

            lb_harga1.Visible = true;
            lb_harga2.Visible = true;
            lb_harga3.Visible = true;

            btn_add1.Visible = true;
            btn_add2.Visible = true;
            btn_add3.Visible = true;
        }
        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            defaultPanel();
            pnl_tshirt.Visible = true;

            defaultVisible();
            lb_nama1.Text = "Airism Cotton T-Shirt";
            lb_nama2.Text = "Short Sleeve T-Shirt";
            lb_nama3.Text = "Linen Crew T-Shirt";

            lb_harga1.Text = "Rp. 200.000,-";
            lb_harga2.Text = "Rp. 149.000,-";
            lb_harga3.Text = "Rp. 350.000,-";

        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            defaultPanel();
            pnl_shirt.Visible = true;

            defaultVisible();
            lb_nama1.Text = "Checked Shirt";
            lb_nama2.Text = "Fine Cotton Shirt";
            lb_nama3.Text = "Premium Linen Shirt";

            lb_harga1.Text = "Rp. 400.000,-";
            lb_harga2.Text = "Rp. 380.000,-";
            lb_harga3.Text = "Rp. 499.000,-";
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            defaultPanel();
            pnl_pants.Visible = true;

            defaultVisible();
            lb_nama1.Text = "Cotton Short Pants";
            lb_nama2.Text = "Linen Short Pants";
            lb_nama3.Text = "Seersucker Short Pants";

            lb_harga1.Text = "Rp. 200.000,-";
            lb_harga2.Text = "Rp. 350.000,-";
            lb_harga3.Text = "Rp. 220.000,-";
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            defaultPanel();
            pnl_longpants.Visible = true;

            defaultVisible();
            lb_nama1.Text = "Linen Long Pants";
            lb_nama2.Text = "Ankle Long Pants";
            lb_nama3.Text = "Denim Long Pants";

            lb_harga1.Text = "Rp. 300.000,-";
            lb_harga2.Text = "Rp. 290.000,-";
            lb_harga3.Text = "Rp. 600.000,-";
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            defaultPanel();
            pnl_shoes.Visible = true;

            defaultVisible();
            lb_nama1.Text = "Platform Sandals";
            lb_nama2.Text = "Comfeel Loafers";
            lb_nama3.Text = "Canvas Shoes";

            lb_harga1.Text = "Rp. 499.000,-";
            lb_harga2.Text = "Rp. 399.000,-";
            lb_harga3.Text = "Rp. 500.000,-";
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            defaultPanel();
            pnl_jewelleries.Visible = true;

            defaultVisible();
            lb_nama1.Text = "3-Pack Rings";
            lb_nama2.Text = "Spherical Earrings";
            lb_nama3.Text = "Chained Earrings";

            lb_harga1.Text = "Rp. 180.000,-";
            lb_harga2.Text = "Rp. 900.000,-";
            lb_harga3.Text = "Rp. 750.000,-";
        }

        private void defaultEnable()
        {
            pbox_others.Image = null;
            tBox_itemname.Enabled = false;
            tBox_itemprice.Enabled = false;
            btn_addothers.Enabled = false;
            tBox_itemname.Clear();
            tBox_itemprice.Clear();
        }
        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            defaultEnable();
            defaultPanel();
            pnl_others.Visible = true;

            lb_nama1.Visible = false;
            lb_nama2.Visible = false;
            lb_nama3.Visible = false;

            lb_harga1.Visible = false;
            lb_harga2.Visible = false;
            lb_harga3.Visible = false;

            btn_add1.Visible = false;
            btn_add2.Visible = false;
            btn_add3.Visible = false;

        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            ofd.Filter = "All Files (*.jpg)|*.jpg";
            ofd.ShowDialog();

            pbox_others.Image = new Bitmap(ofd.FileName);

            tBox_itemname.Enabled = true;
            tBox_itemprice.Enabled=true;

        }
        private void tBox_itemprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void checkTBox()
        {
            if (!string.IsNullOrWhiteSpace(tBox_itemname.Text) && !string.IsNullOrWhiteSpace(tBox_itemprice.Text))
            {
                btn_addothers.Enabled = true;
            }
            else
            {
                btn_addothers.Enabled = false;
            }
        }
        private void tBox_itemname_TextChanged(object sender, EventArgs e)
        {
            checkTBox();
        }

        private void tBox_itemprice_TextChanged(object sender, EventArgs e)
        {
            checkTBox();
        }
        private void subtotalandtotal()
        {
            subTotalprice = 0;

            for (int i = 0; i < dgv1.Rows.Count; i++)
            {
                subTotalprice = subTotalprice + int.Parse(dgv1.Rows[i].Cells[3].Value.ToString());
            }

            tb_subtotal.Text = "Rp " + subTotalprice.ToString("N0") + ",-";
            totalprice = subTotalprice + (10 * subTotalprice) / 100;
            tb_total.Text = "Rp " + totalprice.ToString("N0") + ",-";
        }
        private void btn_addothers_Click(object sender, EventArgs e)
        {
            cek = 0;
            for (int i = 0; i < dgv1.Rows.Count; i++)
            {
                if (dgv1.Rows[i].Cells[0].Value.ToString() == tBox_itemname.Text)
                {
                    cek++;
                    MessageBox.Show("Items with the same name already exist.");
                    break;
                }
            }
            
            if (cek == 0)
            {
                quantity = 1;
                total = quantity * int.Parse(tBox_itemprice.Text);

                dtCart.Rows.Add(tBox_itemname.Text,quantity,tBox_itemprice.Text, total);

            }
            defaultEnable();
            subtotalandtotal();
        }

        private void btn_add1_Click(object sender, EventArgs e)
        {
            cek = 0;

            for (int i = 0; i<dgv1.Rows.Count;i++)
            {
                if (dgv1.Rows[i].Cells[0].Value.ToString() == lb_nama1.Text)
                {
                    cek++;
                    quantity = int.Parse(dgv1.Rows[i].Cells[1].Value.ToString()) + 1;
                    price = int.Parse(Regex.Replace(lb_harga1.Text, @"[^\d]", ""));
                    total = quantity * price;

                    DataGridViewRow row = dgv1.Rows[i];
                    row.Cells[1].Value = quantity;
                    row.Cells[3].Value = total;

                    break;
                }
            }

            if (cek==0)
            {
                quantity = 1;
                price = int.Parse(Regex.Replace(lb_harga1.Text, @"[^\d]", ""));
                total = quantity * Convert.ToInt32(price);

                dtCart.Rows.Add(lb_nama1.Text,quantity,price,total);
            }

            dgv1.ClearSelection();
            subtotalandtotal();
        }

        private void btn_add2_Click(object sender, EventArgs e)
        {
            cek = 0;

            for (int i = 0; i < dgv1.Rows.Count; i++)
            {
                if (dgv1.Rows[i].Cells[0].Value.ToString() == lb_nama2.Text)
                {
                    cek++;
                    quantity = int.Parse(dgv1.Rows[i].Cells[1].Value.ToString()) + 1;
                    price = int.Parse(Regex.Replace(lb_harga2.Text, @"[^\d]", ""));
                    total = quantity * price;

                    DataGridViewRow row = dgv1.Rows[i];
                    row.Cells[1].Value = quantity;
                    row.Cells[3].Value = total;

                    break;
                }
            }

            if (cek == 0)
            {
                quantity = 1;
                price = int.Parse(Regex.Replace(lb_harga2.Text, @"[^\d]", ""));
                total = quantity * price;

                dtCart.Rows.Add(lb_nama2.Text, quantity, price, total);
            }

            dgv1.ClearSelection();
            subtotalandtotal();
        }

        private void btn_add3_Click(object sender, EventArgs e)
        {
            cek = 0;

            for (int i = 0; i < dgv1.Rows.Count; i++)
            {
                if (dgv1.Rows[i].Cells[0].Value.ToString() == lb_nama3.Text)
                {
                    cek++;
                    quantity = int.Parse(dgv1.Rows[i].Cells[1].Value.ToString()) + 1;
                    price = int.Parse(Regex.Replace(lb_harga3.Text, @"[^\d]", ""));
                    total = quantity * price;

                    DataGridViewRow row = dgv1.Rows[i];
                    row.Cells[1].Value = quantity;
                    row.Cells[3].Value = total;

                    break;
                }
            }

            if (cek == 0)
            {
                quantity = 1;
                price = int.Parse(Regex.Replace(lb_harga3.Text, @"[^\d]", ""));
                total = quantity * price;

                dtCart.Rows.Add(lb_nama3.Text, quantity, price, total);
            }

            dgv1.ClearSelection();
            subtotalandtotal();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (pilih != "")
            {
                DataGridViewRow currentRow = dgv1.CurrentRow;
                dgv1.Rows.Remove(currentRow);

                subtotalandtotal();

                pilih = "";
            }
        }

        private void dgv1_Click(object sender, EventArgs e)
        {
            DataGridViewRow currentRow = dgv1.CurrentRow;
            pilih = currentRow.Cells[0].Value.ToString();
        }
    }
}
