﻿namespace Take_Home_Week_9_Rayna_Shera_Chang
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tb_subtotal = new System.Windows.Forms.TextBox();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.lb_nama1 = new System.Windows.Forms.Label();
            this.lb_nama2 = new System.Windows.Forms.Label();
            this.lb_nama3 = new System.Windows.Forms.Label();
            this.btn_add1 = new System.Windows.Forms.Button();
            this.lb_harga1 = new System.Windows.Forms.Label();
            this.lb_harga3 = new System.Windows.Forms.Label();
            this.lb_harga2 = new System.Windows.Forms.Label();
            this.btn_add3 = new System.Windows.Forms.Button();
            this.btn_add2 = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.pnl_others = new System.Windows.Forms.Panel();
            this.tBox_itemprice = new System.Windows.Forms.TextBox();
            this.lb_itemPrice = new System.Windows.Forms.Label();
            this.tBox_itemname = new System.Windows.Forms.TextBox();
            this.lb_itemName = new System.Windows.Forms.Label();
            this.btn_upload = new System.Windows.Forms.Button();
            this.lb_upload = new System.Windows.Forms.Label();
            this.pbox_others = new System.Windows.Forms.PictureBox();
            this.btn_addothers = new System.Windows.Forms.Button();
            this.pnl_tshirt = new System.Windows.Forms.Panel();
            this.pbox_tshirt1 = new System.Windows.Forms.PictureBox();
            this.pbox_tshirt2 = new System.Windows.Forms.PictureBox();
            this.pbox_tshirt3 = new System.Windows.Forms.PictureBox();
            this.pnl_shirt = new System.Windows.Forms.Panel();
            this.pbox_shirt1 = new System.Windows.Forms.PictureBox();
            this.pbox_shirt2 = new System.Windows.Forms.PictureBox();
            this.pbox_shirt3 = new System.Windows.Forms.PictureBox();
            this.pnl_pants = new System.Windows.Forms.Panel();
            this.pbox_pants1 = new System.Windows.Forms.PictureBox();
            this.pbox_pants2 = new System.Windows.Forms.PictureBox();
            this.pbox_pants3 = new System.Windows.Forms.PictureBox();
            this.pnl_longpants = new System.Windows.Forms.Panel();
            this.pbox_longpants1 = new System.Windows.Forms.PictureBox();
            this.pbox_longpants2 = new System.Windows.Forms.PictureBox();
            this.pbox_longpants3 = new System.Windows.Forms.PictureBox();
            this.pnl_shoes = new System.Windows.Forms.Panel();
            this.pbox_shoes1 = new System.Windows.Forms.PictureBox();
            this.pbox_shoes2 = new System.Windows.Forms.PictureBox();
            this.pbox_shoes3 = new System.Windows.Forms.PictureBox();
            this.pnl_jewelleries = new System.Windows.Forms.Panel();
            this.pbox_jewel1 = new System.Windows.Forms.PictureBox();
            this.pbox_jewel2 = new System.Windows.Forms.PictureBox();
            this.pbox_jewel3 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            this.pnl_others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_others)).BeginInit();
            this.pnl_tshirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_tshirt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_tshirt2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_tshirt3)).BeginInit();
            this.pnl_shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shirt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shirt2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shirt3)).BeginInit();
            this.pnl_pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_pants1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_pants2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_pants3)).BeginInit();
            this.pnl_longpants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_longpants1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_longpants2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_longpants3)).BeginInit();
            this.pnl_shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shoes1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shoes2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shoes3)).BeginInit();
            this.pnl_jewelleries.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_jewel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_jewel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_jewel3)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1173, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(102, 29);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomToolStripMenuItem
            // 
            this.bottomToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomToolStripMenuItem.Name = "bottomToolStripMenuItem";
            this.bottomToolStripMenuItem.Size = new System.Drawing.Size(88, 29);
            this.bottomToolStripMenuItem.Text = "Bottom";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(119, 29);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(81, 29);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dgv1
            // 
            this.dgv1.AllowUserToAddRows = false;
            this.dgv1.AllowUserToResizeColumns = false;
            this.dgv1.AllowUserToResizeRows = false;
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv1.Location = new System.Drawing.Point(535, 51);
            this.dgv1.Name = "dgv1";
            this.dgv1.ReadOnly = true;
            this.dgv1.RowHeadersVisible = false;
            this.dgv1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgv1.RowTemplate.Height = 28;
            this.dgv1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv1.Size = new System.Drawing.Size(599, 334);
            this.dgv1.TabIndex = 38;
            this.dgv1.Click += new System.EventHandler(this.dgv1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(529, 398);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sub-Total:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(584, 438);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 29);
            this.label2.TabIndex = 3;
            this.label2.Text = "Total:";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // tb_subtotal
            // 
            this.tb_subtotal.Enabled = false;
            this.tb_subtotal.Location = new System.Drawing.Point(679, 401);
            this.tb_subtotal.Name = "tb_subtotal";
            this.tb_subtotal.Size = new System.Drawing.Size(181, 26);
            this.tb_subtotal.TabIndex = 5;
            // 
            // tb_total
            // 
            this.tb_total.Enabled = false;
            this.tb_total.Location = new System.Drawing.Point(679, 438);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(181, 26);
            this.tb_total.TabIndex = 6;
            // 
            // lb_nama1
            // 
            this.lb_nama1.AutoSize = true;
            this.lb_nama1.Location = new System.Drawing.Point(21, 275);
            this.lb_nama1.Name = "lb_nama1";
            this.lb_nama1.Size = new System.Drawing.Size(58, 20);
            this.lb_nama1.TabIndex = 10;
            this.lb_nama1.Text = "nama1";
            this.lb_nama1.Visible = false;
            // 
            // lb_nama2
            // 
            this.lb_nama2.AutoSize = true;
            this.lb_nama2.Location = new System.Drawing.Point(186, 275);
            this.lb_nama2.Name = "lb_nama2";
            this.lb_nama2.Size = new System.Drawing.Size(58, 20);
            this.lb_nama2.TabIndex = 11;
            this.lb_nama2.Text = "nama2";
            this.lb_nama2.Visible = false;
            // 
            // lb_nama3
            // 
            this.lb_nama3.AutoSize = true;
            this.lb_nama3.Location = new System.Drawing.Point(350, 275);
            this.lb_nama3.Name = "lb_nama3";
            this.lb_nama3.Size = new System.Drawing.Size(58, 20);
            this.lb_nama3.TabIndex = 12;
            this.lb_nama3.Text = "nama3";
            this.lb_nama3.Visible = false;
            // 
            // btn_add1
            // 
            this.btn_add1.Location = new System.Drawing.Point(25, 339);
            this.btn_add1.Name = "btn_add1";
            this.btn_add1.Size = new System.Drawing.Size(107, 30);
            this.btn_add1.TabIndex = 13;
            this.btn_add1.Text = "Add to Cart";
            this.btn_add1.UseVisualStyleBackColor = true;
            this.btn_add1.Visible = false;
            this.btn_add1.Click += new System.EventHandler(this.btn_add1_Click);
            // 
            // lb_harga1
            // 
            this.lb_harga1.AutoSize = true;
            this.lb_harga1.Location = new System.Drawing.Point(21, 304);
            this.lb_harga1.Name = "lb_harga1";
            this.lb_harga1.Size = new System.Drawing.Size(59, 20);
            this.lb_harga1.TabIndex = 14;
            this.lb_harga1.Text = "harga1";
            this.lb_harga1.Visible = false;
            // 
            // lb_harga3
            // 
            this.lb_harga3.AutoSize = true;
            this.lb_harga3.Location = new System.Drawing.Point(350, 304);
            this.lb_harga3.Name = "lb_harga3";
            this.lb_harga3.Size = new System.Drawing.Size(59, 20);
            this.lb_harga3.TabIndex = 15;
            this.lb_harga3.Text = "harga3";
            this.lb_harga3.Visible = false;
            // 
            // lb_harga2
            // 
            this.lb_harga2.AutoSize = true;
            this.lb_harga2.Location = new System.Drawing.Point(186, 304);
            this.lb_harga2.Name = "lb_harga2";
            this.lb_harga2.Size = new System.Drawing.Size(59, 20);
            this.lb_harga2.TabIndex = 16;
            this.lb_harga2.Text = "harga2";
            this.lb_harga2.Visible = false;
            // 
            // btn_add3
            // 
            this.btn_add3.Location = new System.Drawing.Point(354, 339);
            this.btn_add3.Name = "btn_add3";
            this.btn_add3.Size = new System.Drawing.Size(107, 30);
            this.btn_add3.TabIndex = 17;
            this.btn_add3.Text = "Add to Cart";
            this.btn_add3.UseVisualStyleBackColor = true;
            this.btn_add3.Visible = false;
            this.btn_add3.Click += new System.EventHandler(this.btn_add3_Click);
            // 
            // btn_add2
            // 
            this.btn_add2.Location = new System.Drawing.Point(190, 339);
            this.btn_add2.Name = "btn_add2";
            this.btn_add2.Size = new System.Drawing.Size(107, 30);
            this.btn_add2.TabIndex = 18;
            this.btn_add2.Text = "Add to Cart";
            this.btn_add2.UseVisualStyleBackColor = true;
            this.btn_add2.Visible = false;
            this.btn_add2.Click += new System.EventHandler(this.btn_add2_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(996, 397);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(138, 30);
            this.btn_delete.TabIndex = 19;
            this.btn_delete.Text = "Delete Cart";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // pnl_others
            // 
            this.pnl_others.Controls.Add(this.tBox_itemprice);
            this.pnl_others.Controls.Add(this.lb_itemPrice);
            this.pnl_others.Controls.Add(this.tBox_itemname);
            this.pnl_others.Controls.Add(this.lb_itemName);
            this.pnl_others.Controls.Add(this.btn_upload);
            this.pnl_others.Controls.Add(this.lb_upload);
            this.pnl_others.Controls.Add(this.pbox_others);
            this.pnl_others.Controls.Add(this.btn_addothers);
            this.pnl_others.Location = new System.Drawing.Point(59, 51);
            this.pnl_others.Name = "pnl_others";
            this.pnl_others.Size = new System.Drawing.Size(350, 270);
            this.pnl_others.TabIndex = 50;
            this.pnl_others.Visible = false;
            // 
            // tBox_itemprice
            // 
            this.tBox_itemprice.Enabled = false;
            this.tBox_itemprice.Location = new System.Drawing.Point(183, 159);
            this.tBox_itemprice.Name = "tBox_itemprice";
            this.tBox_itemprice.Size = new System.Drawing.Size(152, 26);
            this.tBox_itemprice.TabIndex = 53;
            this.tBox_itemprice.TextChanged += new System.EventHandler(this.tBox_itemprice_TextChanged);
            this.tBox_itemprice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBox_itemprice_KeyPress);
            // 
            // lb_itemPrice
            // 
            this.lb_itemPrice.AutoSize = true;
            this.lb_itemPrice.Location = new System.Drawing.Point(179, 131);
            this.lb_itemPrice.Name = "lb_itemPrice";
            this.lb_itemPrice.Size = new System.Drawing.Size(84, 20);
            this.lb_itemPrice.TabIndex = 54;
            this.lb_itemPrice.Text = "Item Price:";
            // 
            // tBox_itemname
            // 
            this.tBox_itemname.Enabled = false;
            this.tBox_itemname.Location = new System.Drawing.Point(183, 91);
            this.tBox_itemname.Name = "tBox_itemname";
            this.tBox_itemname.Size = new System.Drawing.Size(152, 26);
            this.tBox_itemname.TabIndex = 50;
            this.tBox_itemname.TextChanged += new System.EventHandler(this.tBox_itemname_TextChanged);
            // 
            // lb_itemName
            // 
            this.lb_itemName.AutoSize = true;
            this.lb_itemName.Location = new System.Drawing.Point(179, 63);
            this.lb_itemName.Name = "lb_itemName";
            this.lb_itemName.Size = new System.Drawing.Size(91, 20);
            this.lb_itemName.TabIndex = 52;
            this.lb_itemName.Text = "Item Name:";
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(136, 5);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(127, 33);
            this.btn_upload.TabIndex = 51;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // lb_upload
            // 
            this.lb_upload.AutoSize = true;
            this.lb_upload.Location = new System.Drawing.Point(9, 11);
            this.lb_upload.Name = "lb_upload";
            this.lb_upload.Size = new System.Drawing.Size(109, 20);
            this.lb_upload.TabIndex = 49;
            this.lb_upload.Text = "Upload Image";
            // 
            // pbox_others
            // 
            this.pbox_others.Location = new System.Drawing.Point(13, 63);
            this.pbox_others.Name = "pbox_others";
            this.pbox_others.Size = new System.Drawing.Size(149, 201);
            this.pbox_others.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_others.TabIndex = 48;
            this.pbox_others.TabStop = false;
            // 
            // btn_addothers
            // 
            this.btn_addothers.Enabled = false;
            this.btn_addothers.Location = new System.Drawing.Point(183, 231);
            this.btn_addothers.Name = "btn_addothers";
            this.btn_addothers.Size = new System.Drawing.Size(127, 33);
            this.btn_addothers.TabIndex = 55;
            this.btn_addothers.Text = "Add to Cart";
            this.btn_addothers.UseVisualStyleBackColor = true;
            this.btn_addothers.Click += new System.EventHandler(this.btn_addothers_Click);
            // 
            // pnl_tshirt
            // 
            this.pnl_tshirt.Controls.Add(this.pbox_tshirt1);
            this.pnl_tshirt.Controls.Add(this.pbox_tshirt2);
            this.pnl_tshirt.Controls.Add(this.pbox_tshirt3);
            this.pnl_tshirt.Location = new System.Drawing.Point(25, 51);
            this.pnl_tshirt.Name = "pnl_tshirt";
            this.pnl_tshirt.Size = new System.Drawing.Size(470, 188);
            this.pnl_tshirt.TabIndex = 51;
            this.pnl_tshirt.Visible = false;
            // 
            // pbox_tshirt1
            // 
            this.pbox_tshirt1.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Airism_Cotton_T_Shirt;
            this.pbox_tshirt1.Location = new System.Drawing.Point(0, 0);
            this.pbox_tshirt1.Name = "pbox_tshirt1";
            this.pbox_tshirt1.Size = new System.Drawing.Size(141, 188);
            this.pbox_tshirt1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_tshirt1.TabIndex = 54;
            this.pbox_tshirt1.TabStop = false;
            // 
            // pbox_tshirt2
            // 
            this.pbox_tshirt2.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Short_Sleeve_T_Shirt;
            this.pbox_tshirt2.Location = new System.Drawing.Point(165, 0);
            this.pbox_tshirt2.Name = "pbox_tshirt2";
            this.pbox_tshirt2.Size = new System.Drawing.Size(141, 188);
            this.pbox_tshirt2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_tshirt2.TabIndex = 53;
            this.pbox_tshirt2.TabStop = false;
            // 
            // pbox_tshirt3
            // 
            this.pbox_tshirt3.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Linen_Crew_Neck_T_Shirt;
            this.pbox_tshirt3.Location = new System.Drawing.Point(329, 0);
            this.pbox_tshirt3.Name = "pbox_tshirt3";
            this.pbox_tshirt3.Size = new System.Drawing.Size(141, 188);
            this.pbox_tshirt3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_tshirt3.TabIndex = 52;
            this.pbox_tshirt3.TabStop = false;
            // 
            // pnl_shirt
            // 
            this.pnl_shirt.Controls.Add(this.pbox_shirt1);
            this.pnl_shirt.Controls.Add(this.pbox_shirt2);
            this.pnl_shirt.Controls.Add(this.pbox_shirt3);
            this.pnl_shirt.Location = new System.Drawing.Point(25, 51);
            this.pnl_shirt.Name = "pnl_shirt";
            this.pnl_shirt.Size = new System.Drawing.Size(470, 188);
            this.pnl_shirt.TabIndex = 55;
            // 
            // pbox_shirt1
            // 
            this.pbox_shirt1.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Checked_Shirt;
            this.pbox_shirt1.Location = new System.Drawing.Point(0, 0);
            this.pbox_shirt1.Name = "pbox_shirt1";
            this.pbox_shirt1.Size = new System.Drawing.Size(141, 188);
            this.pbox_shirt1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_shirt1.TabIndex = 54;
            this.pbox_shirt1.TabStop = false;
            // 
            // pbox_shirt2
            // 
            this.pbox_shirt2.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Fine_Cotton_Shirt;
            this.pbox_shirt2.Location = new System.Drawing.Point(165, 0);
            this.pbox_shirt2.Name = "pbox_shirt2";
            this.pbox_shirt2.Size = new System.Drawing.Size(141, 188);
            this.pbox_shirt2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_shirt2.TabIndex = 53;
            this.pbox_shirt2.TabStop = false;
            // 
            // pbox_shirt3
            // 
            this.pbox_shirt3.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Premium_Linen_Shirt;
            this.pbox_shirt3.Location = new System.Drawing.Point(329, 0);
            this.pbox_shirt3.Name = "pbox_shirt3";
            this.pbox_shirt3.Size = new System.Drawing.Size(141, 188);
            this.pbox_shirt3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_shirt3.TabIndex = 52;
            this.pbox_shirt3.TabStop = false;
            // 
            // pnl_pants
            // 
            this.pnl_pants.Controls.Add(this.pbox_pants1);
            this.pnl_pants.Controls.Add(this.pbox_pants2);
            this.pnl_pants.Controls.Add(this.pbox_pants3);
            this.pnl_pants.Location = new System.Drawing.Point(25, 51);
            this.pnl_pants.Name = "pnl_pants";
            this.pnl_pants.Size = new System.Drawing.Size(470, 188);
            this.pnl_pants.TabIndex = 56;
            // 
            // pbox_pants1
            // 
            this.pbox_pants1.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Cotton_Short_Pants_;
            this.pbox_pants1.Location = new System.Drawing.Point(0, 0);
            this.pbox_pants1.Name = "pbox_pants1";
            this.pbox_pants1.Size = new System.Drawing.Size(141, 188);
            this.pbox_pants1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_pants1.TabIndex = 54;
            this.pbox_pants1.TabStop = false;
            // 
            // pbox_pants2
            // 
            this.pbox_pants2.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Linen_Short_Pants;
            this.pbox_pants2.Location = new System.Drawing.Point(165, 0);
            this.pbox_pants2.Name = "pbox_pants2";
            this.pbox_pants2.Size = new System.Drawing.Size(141, 188);
            this.pbox_pants2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_pants2.TabIndex = 53;
            this.pbox_pants2.TabStop = false;
            // 
            // pbox_pants3
            // 
            this.pbox_pants3.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Seersucker_Short_Pants;
            this.pbox_pants3.Location = new System.Drawing.Point(329, 0);
            this.pbox_pants3.Name = "pbox_pants3";
            this.pbox_pants3.Size = new System.Drawing.Size(141, 188);
            this.pbox_pants3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_pants3.TabIndex = 52;
            this.pbox_pants3.TabStop = false;
            // 
            // pnl_longpants
            // 
            this.pnl_longpants.Controls.Add(this.pbox_longpants1);
            this.pnl_longpants.Controls.Add(this.pbox_longpants2);
            this.pnl_longpants.Controls.Add(this.pbox_longpants3);
            this.pnl_longpants.Location = new System.Drawing.Point(25, 51);
            this.pnl_longpants.Name = "pnl_longpants";
            this.pnl_longpants.Size = new System.Drawing.Size(470, 188);
            this.pnl_longpants.TabIndex = 57;
            // 
            // pbox_longpants1
            // 
            this.pbox_longpants1.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Linen_Long_Pants;
            this.pbox_longpants1.Location = new System.Drawing.Point(0, 0);
            this.pbox_longpants1.Name = "pbox_longpants1";
            this.pbox_longpants1.Size = new System.Drawing.Size(141, 188);
            this.pbox_longpants1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_longpants1.TabIndex = 54;
            this.pbox_longpants1.TabStop = false;
            // 
            // pbox_longpants2
            // 
            this.pbox_longpants2.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Ankle_Long_Pants;
            this.pbox_longpants2.Location = new System.Drawing.Point(165, 0);
            this.pbox_longpants2.Name = "pbox_longpants2";
            this.pbox_longpants2.Size = new System.Drawing.Size(141, 188);
            this.pbox_longpants2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_longpants2.TabIndex = 53;
            this.pbox_longpants2.TabStop = false;
            // 
            // pbox_longpants3
            // 
            this.pbox_longpants3.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Denim_Long_Pants;
            this.pbox_longpants3.Location = new System.Drawing.Point(329, 0);
            this.pbox_longpants3.Name = "pbox_longpants3";
            this.pbox_longpants3.Size = new System.Drawing.Size(141, 188);
            this.pbox_longpants3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_longpants3.TabIndex = 52;
            this.pbox_longpants3.TabStop = false;
            // 
            // pnl_shoes
            // 
            this.pnl_shoes.Controls.Add(this.pbox_shoes1);
            this.pnl_shoes.Controls.Add(this.pbox_shoes2);
            this.pnl_shoes.Controls.Add(this.pbox_shoes3);
            this.pnl_shoes.Location = new System.Drawing.Point(25, 51);
            this.pnl_shoes.Name = "pnl_shoes";
            this.pnl_shoes.Size = new System.Drawing.Size(470, 188);
            this.pnl_shoes.TabIndex = 58;
            // 
            // pbox_shoes1
            // 
            this.pbox_shoes1.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Platform_Sandals;
            this.pbox_shoes1.Location = new System.Drawing.Point(0, 0);
            this.pbox_shoes1.Name = "pbox_shoes1";
            this.pbox_shoes1.Size = new System.Drawing.Size(141, 188);
            this.pbox_shoes1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_shoes1.TabIndex = 54;
            this.pbox_shoes1.TabStop = false;
            // 
            // pbox_shoes2
            // 
            this.pbox_shoes2.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Comfeel_Loafers;
            this.pbox_shoes2.Location = new System.Drawing.Point(165, 0);
            this.pbox_shoes2.Name = "pbox_shoes2";
            this.pbox_shoes2.Size = new System.Drawing.Size(141, 188);
            this.pbox_shoes2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_shoes2.TabIndex = 53;
            this.pbox_shoes2.TabStop = false;
            // 
            // pbox_shoes3
            // 
            this.pbox_shoes3.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Canvas_Shoes;
            this.pbox_shoes3.Location = new System.Drawing.Point(329, 0);
            this.pbox_shoes3.Name = "pbox_shoes3";
            this.pbox_shoes3.Size = new System.Drawing.Size(141, 188);
            this.pbox_shoes3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_shoes3.TabIndex = 52;
            this.pbox_shoes3.TabStop = false;
            // 
            // pnl_jewelleries
            // 
            this.pnl_jewelleries.Controls.Add(this.pbox_jewel1);
            this.pnl_jewelleries.Controls.Add(this.pbox_jewel2);
            this.pnl_jewelleries.Controls.Add(this.pbox_jewel3);
            this.pnl_jewelleries.Location = new System.Drawing.Point(25, 51);
            this.pnl_jewelleries.Name = "pnl_jewelleries";
            this.pnl_jewelleries.Size = new System.Drawing.Size(470, 188);
            this.pnl_jewelleries.TabIndex = 59;
            // 
            // pbox_jewel1
            // 
            this.pbox_jewel1.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources._3_Pack_Rings;
            this.pbox_jewel1.Location = new System.Drawing.Point(0, 0);
            this.pbox_jewel1.Name = "pbox_jewel1";
            this.pbox_jewel1.Size = new System.Drawing.Size(141, 188);
            this.pbox_jewel1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_jewel1.TabIndex = 54;
            this.pbox_jewel1.TabStop = false;
            // 
            // pbox_jewel2
            // 
            this.pbox_jewel2.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Spherical_Earrings;
            this.pbox_jewel2.Location = new System.Drawing.Point(165, 0);
            this.pbox_jewel2.Name = "pbox_jewel2";
            this.pbox_jewel2.Size = new System.Drawing.Size(141, 188);
            this.pbox_jewel2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_jewel2.TabIndex = 53;
            this.pbox_jewel2.TabStop = false;
            // 
            // pbox_jewel3
            // 
            this.pbox_jewel3.Image = global::Take_Home_Week_9_Rayna_Shera_Chang.Properties.Resources.Chaines_Earrings;
            this.pbox_jewel3.Location = new System.Drawing.Point(329, 0);
            this.pbox_jewel3.Name = "pbox_jewel3";
            this.pbox_jewel3.Size = new System.Drawing.Size(141, 188);
            this.pbox_jewel3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_jewel3.TabIndex = 52;
            this.pbox_jewel3.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1173, 494);
            this.Controls.Add(this.pnl_tshirt);
            this.Controls.Add(this.pnl_jewelleries);
            this.Controls.Add(this.pnl_shoes);
            this.Controls.Add(this.pnl_longpants);
            this.Controls.Add(this.pnl_pants);
            this.Controls.Add(this.pnl_shirt);
            this.Controls.Add(this.pnl_others);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add2);
            this.Controls.Add(this.btn_add3);
            this.Controls.Add(this.lb_harga2);
            this.Controls.Add(this.lb_harga3);
            this.Controls.Add(this.lb_harga1);
            this.Controls.Add(this.btn_add1);
            this.Controls.Add(this.lb_nama3);
            this.Controls.Add(this.lb_nama2);
            this.Controls.Add(this.lb_nama1);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.tb_subtotal);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgv1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            this.pnl_others.ResumeLayout(false);
            this.pnl_others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_others)).EndInit();
            this.pnl_tshirt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbox_tshirt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_tshirt2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_tshirt3)).EndInit();
            this.pnl_shirt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shirt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shirt2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shirt3)).EndInit();
            this.pnl_pants.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbox_pants1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_pants2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_pants3)).EndInit();
            this.pnl_longpants.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbox_longpants1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_longpants2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_longpants3)).EndInit();
            this.pnl_shoes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shoes1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shoes2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shoes3)).EndInit();
            this.pnl_jewelleries.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbox_jewel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_jewel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_jewel3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox tb_subtotal;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.Label lb_nama1;
        private System.Windows.Forms.Label lb_nama2;
        private System.Windows.Forms.Label lb_nama3;
        private System.Windows.Forms.Button btn_add1;
        private System.Windows.Forms.Label lb_harga1;
        private System.Windows.Forms.Label lb_harga3;
        private System.Windows.Forms.Label lb_harga2;
        private System.Windows.Forms.Button btn_add3;
        private System.Windows.Forms.Button btn_add2;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Panel pnl_others;
        private System.Windows.Forms.TextBox tBox_itemprice;
        private System.Windows.Forms.Label lb_itemPrice;
        private System.Windows.Forms.TextBox tBox_itemname;
        private System.Windows.Forms.Label lb_itemName;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.Label lb_upload;
        private System.Windows.Forms.PictureBox pbox_others;
        private System.Windows.Forms.Button btn_addothers;
        private System.Windows.Forms.Panel pnl_tshirt;
        private System.Windows.Forms.PictureBox pbox_tshirt1;
        private System.Windows.Forms.PictureBox pbox_tshirt2;
        private System.Windows.Forms.PictureBox pbox_tshirt3;
        private System.Windows.Forms.Panel pnl_shirt;
        private System.Windows.Forms.Panel pnl_pants;
        private System.Windows.Forms.PictureBox pbox_pants1;
        private System.Windows.Forms.PictureBox pbox_pants2;
        private System.Windows.Forms.PictureBox pbox_pants3;
        private System.Windows.Forms.PictureBox pbox_shirt1;
        private System.Windows.Forms.PictureBox pbox_shirt2;
        private System.Windows.Forms.PictureBox pbox_shirt3;
        private System.Windows.Forms.Panel pnl_longpants;
        private System.Windows.Forms.PictureBox pbox_longpants1;
        private System.Windows.Forms.PictureBox pbox_longpants2;
        private System.Windows.Forms.PictureBox pbox_longpants3;
        private System.Windows.Forms.Panel pnl_shoes;
        private System.Windows.Forms.PictureBox pbox_shoes1;
        private System.Windows.Forms.PictureBox pbox_shoes2;
        private System.Windows.Forms.PictureBox pbox_shoes3;
        private System.Windows.Forms.Panel pnl_jewelleries;
        private System.Windows.Forms.PictureBox pbox_jewel1;
        private System.Windows.Forms.PictureBox pbox_jewel2;
        private System.Windows.Forms.PictureBox pbox_jewel3;
    }
}

