﻿namespace Take_Home_Week_5_Rayna_Shera_Chang
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lb_Product = new System.Windows.Forms.Label();
            this.btn_All = new System.Windows.Forms.Button();
            this.btn_Filter = new System.Windows.Forms.Button();
            this.dgv_Product = new System.Windows.Forms.DataGridView();
            this.dgv_Category = new System.Windows.Forms.DataGridView();
            this.cb_Filter = new System.Windows.Forms.ComboBox();
            this.lb_Category = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lb_NamaCategory = new System.Windows.Forms.Label();
            this.lb_DNama = new System.Windows.Forms.Label();
            this.lb_DCategory = new System.Windows.Forms.Label();
            this.lb_DHarga = new System.Windows.Forms.Label();
            this.lb_DStock = new System.Windows.Forms.Label();
            this.tb_NamaProduct = new System.Windows.Forms.TextBox();
            this.tb_Harga = new System.Windows.Forms.TextBox();
            this.tb_Stock = new System.Windows.Forms.TextBox();
            this.tb_NamaCategory = new System.Windows.Forms.TextBox();
            this.cb_Category = new System.Windows.Forms.ComboBox();
            this.btn_AddProduct = new System.Windows.Forms.Button();
            this.btn_EditProduct = new System.Windows.Forms.Button();
            this.btn_RemoveProduct = new System.Windows.Forms.Button();
            this.btn_AddCategory = new System.Windows.Forms.Button();
            this.btn_RemoveCategory = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_Product
            // 
            this.lb_Product.AutoSize = true;
            this.lb_Product.Font = new System.Drawing.Font("72 Monospace", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Product.Location = new System.Drawing.Point(30, 31);
            this.lb_Product.Name = "lb_Product";
            this.lb_Product.Size = new System.Drawing.Size(133, 31);
            this.lb_Product.TabIndex = 0;
            this.lb_Product.Text = "Product";
            // 
            // btn_All
            // 
            this.btn_All.Location = new System.Drawing.Point(226, 55);
            this.btn_All.Name = "btn_All";
            this.btn_All.Size = new System.Drawing.Size(75, 33);
            this.btn_All.TabIndex = 1;
            this.btn_All.Text = "All";
            this.btn_All.UseVisualStyleBackColor = true;
            this.btn_All.Click += new System.EventHandler(this.btn_All_Click);
            // 
            // btn_Filter
            // 
            this.btn_Filter.Location = new System.Drawing.Point(311, 55);
            this.btn_Filter.Name = "btn_Filter";
            this.btn_Filter.Size = new System.Drawing.Size(75, 33);
            this.btn_Filter.TabIndex = 2;
            this.btn_Filter.Text = "Filter:";
            this.btn_Filter.UseVisualStyleBackColor = true;
            this.btn_Filter.Click += new System.EventHandler(this.btn_Filter_Click);
            // 
            // dgv_Product
            // 
            this.dgv_Product.AllowUserToAddRows = false;
            this.dgv_Product.AllowUserToResizeColumns = false;
            this.dgv_Product.AllowUserToResizeRows = false;
            this.dgv_Product.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Product.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_Product.Location = new System.Drawing.Point(36, 94);
            this.dgv_Product.Name = "dgv_Product";
            this.dgv_Product.ReadOnly = true;
            this.dgv_Product.RowHeadersVisible = false;
            this.dgv_Product.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgv_Product.RowTemplate.Height = 28;
            this.dgv_Product.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Product.Size = new System.Drawing.Size(628, 310);
            this.dgv_Product.TabIndex = 3;
            this.dgv_Product.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_Product_CellMouseClick);
            // 
            // dgv_Category
            // 
            this.dgv_Category.AllowUserToAddRows = false;
            this.dgv_Category.AllowUserToResizeColumns = false;
            this.dgv_Category.AllowUserToResizeRows = false;
            this.dgv_Category.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Category.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_Category.Location = new System.Drawing.Point(739, 94);
            this.dgv_Category.Name = "dgv_Category";
            this.dgv_Category.ReadOnly = true;
            this.dgv_Category.RowHeadersVisible = false;
            this.dgv_Category.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgv_Category.RowTemplate.Height = 28;
            this.dgv_Category.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Category.Size = new System.Drawing.Size(322, 222);
            this.dgv_Category.TabIndex = 4;
            this.dgv_Category.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_Category_CellMouseClick);
            // 
            // cb_Filter
            // 
            this.cb_Filter.Enabled = false;
            this.cb_Filter.FormattingEnabled = true;
            this.cb_Filter.Location = new System.Drawing.Point(396, 58);
            this.cb_Filter.Name = "cb_Filter";
            this.cb_Filter.Size = new System.Drawing.Size(147, 28);
            this.cb_Filter.TabIndex = 5;
            this.cb_Filter.SelectedIndexChanged += new System.EventHandler(this.cb_Filter_SelectedIndexChanged);
            // 
            // lb_Category
            // 
            this.lb_Category.AutoSize = true;
            this.lb_Category.Font = new System.Drawing.Font("72 Monospace", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Category.Location = new System.Drawing.Point(733, 31);
            this.lb_Category.Name = "lb_Category";
            this.lb_Category.Size = new System.Drawing.Size(150, 31);
            this.lb_Category.TabIndex = 6;
            this.lb_Category.Text = "Category";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("72 Monospace", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(30, 427);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 31);
            this.label3.TabIndex = 7;
            this.label3.Text = "Details";
            // 
            // lb_NamaCategory
            // 
            this.lb_NamaCategory.AutoSize = true;
            this.lb_NamaCategory.Location = new System.Drawing.Point(736, 339);
            this.lb_NamaCategory.Name = "lb_NamaCategory";
            this.lb_NamaCategory.Size = new System.Drawing.Size(59, 20);
            this.lb_NamaCategory.TabIndex = 8;
            this.lb_NamaCategory.Text = "Nama :";
            // 
            // lb_DNama
            // 
            this.lb_DNama.AutoSize = true;
            this.lb_DNama.Location = new System.Drawing.Point(54, 472);
            this.lb_DNama.Name = "lb_DNama";
            this.lb_DNama.Size = new System.Drawing.Size(59, 20);
            this.lb_DNama.TabIndex = 9;
            this.lb_DNama.Text = "Nama :";
            // 
            // lb_DCategory
            // 
            this.lb_DCategory.AutoSize = true;
            this.lb_DCategory.Location = new System.Drawing.Point(32, 504);
            this.lb_DCategory.Name = "lb_DCategory";
            this.lb_DCategory.Size = new System.Drawing.Size(81, 20);
            this.lb_DCategory.TabIndex = 10;
            this.lb_DCategory.Text = "Category :";
            // 
            // lb_DHarga
            // 
            this.lb_DHarga.AutoSize = true;
            this.lb_DHarga.Location = new System.Drawing.Point(52, 539);
            this.lb_DHarga.Name = "lb_DHarga";
            this.lb_DHarga.Size = new System.Drawing.Size(61, 20);
            this.lb_DHarga.TabIndex = 11;
            this.lb_DHarga.Text = "Harga :";
            // 
            // lb_DStock
            // 
            this.lb_DStock.AutoSize = true;
            this.lb_DStock.Location = new System.Drawing.Point(54, 575);
            this.lb_DStock.Name = "lb_DStock";
            this.lb_DStock.Size = new System.Drawing.Size(58, 20);
            this.lb_DStock.TabIndex = 12;
            this.lb_DStock.Text = "Stock :";
            // 
            // tb_NamaProduct
            // 
            this.tb_NamaProduct.Location = new System.Drawing.Point(150, 471);
            this.tb_NamaProduct.Name = "tb_NamaProduct";
            this.tb_NamaProduct.Size = new System.Drawing.Size(514, 26);
            this.tb_NamaProduct.TabIndex = 13;
            // 
            // tb_Harga
            // 
            this.tb_Harga.Location = new System.Drawing.Point(150, 539);
            this.tb_Harga.Name = "tb_Harga";
            this.tb_Harga.Size = new System.Drawing.Size(194, 26);
            this.tb_Harga.TabIndex = 14;
            this.tb_Harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Harga_KeyPress);
            // 
            // tb_Stock
            // 
            this.tb_Stock.Location = new System.Drawing.Point(150, 574);
            this.tb_Stock.Name = "tb_Stock";
            this.tb_Stock.Size = new System.Drawing.Size(194, 26);
            this.tb_Stock.TabIndex = 15;
            this.tb_Stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Stock_KeyPress);
            // 
            // tb_NamaCategory
            // 
            this.tb_NamaCategory.Location = new System.Drawing.Point(815, 339);
            this.tb_NamaCategory.Name = "tb_NamaCategory";
            this.tb_NamaCategory.Size = new System.Drawing.Size(246, 26);
            this.tb_NamaCategory.TabIndex = 16;
            // 
            // cb_Category
            // 
            this.cb_Category.FormattingEnabled = true;
            this.cb_Category.Location = new System.Drawing.Point(150, 504);
            this.cb_Category.Name = "cb_Category";
            this.cb_Category.Size = new System.Drawing.Size(194, 28);
            this.cb_Category.TabIndex = 17;
            // 
            // btn_AddProduct
            // 
            this.btn_AddProduct.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btn_AddProduct.Location = new System.Drawing.Point(387, 523);
            this.btn_AddProduct.Name = "btn_AddProduct";
            this.btn_AddProduct.Size = new System.Drawing.Size(92, 58);
            this.btn_AddProduct.TabIndex = 18;
            this.btn_AddProduct.Text = "Add Product";
            this.btn_AddProduct.UseVisualStyleBackColor = false;
            this.btn_AddProduct.Click += new System.EventHandler(this.btn_AddProduct_Click);
            // 
            // btn_EditProduct
            // 
            this.btn_EditProduct.BackColor = System.Drawing.Color.Thistle;
            this.btn_EditProduct.Location = new System.Drawing.Point(485, 523);
            this.btn_EditProduct.Name = "btn_EditProduct";
            this.btn_EditProduct.Size = new System.Drawing.Size(92, 58);
            this.btn_EditProduct.TabIndex = 19;
            this.btn_EditProduct.Text = "Edit Product";
            this.btn_EditProduct.UseVisualStyleBackColor = false;
            this.btn_EditProduct.Click += new System.EventHandler(this.btn_EditProduct_Click);
            // 
            // btn_RemoveProduct
            // 
            this.btn_RemoveProduct.BackColor = System.Drawing.Color.Pink;
            this.btn_RemoveProduct.Location = new System.Drawing.Point(583, 522);
            this.btn_RemoveProduct.Name = "btn_RemoveProduct";
            this.btn_RemoveProduct.Size = new System.Drawing.Size(92, 58);
            this.btn_RemoveProduct.TabIndex = 20;
            this.btn_RemoveProduct.Text = "Remove Product";
            this.btn_RemoveProduct.UseVisualStyleBackColor = false;
            this.btn_RemoveProduct.Click += new System.EventHandler(this.btn_RemoveProduct_Click);
            // 
            // btn_AddCategory
            // 
            this.btn_AddCategory.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btn_AddCategory.Location = new System.Drawing.Point(879, 376);
            this.btn_AddCategory.Name = "btn_AddCategory";
            this.btn_AddCategory.Size = new System.Drawing.Size(88, 58);
            this.btn_AddCategory.TabIndex = 21;
            this.btn_AddCategory.Text = "Add Category";
            this.btn_AddCategory.UseVisualStyleBackColor = false;
            this.btn_AddCategory.Click += new System.EventHandler(this.btn_AddCategory_Click);
            // 
            // btn_RemoveCategory
            // 
            this.btn_RemoveCategory.BackColor = System.Drawing.Color.Pink;
            this.btn_RemoveCategory.Location = new System.Drawing.Point(973, 376);
            this.btn_RemoveCategory.Name = "btn_RemoveCategory";
            this.btn_RemoveCategory.Size = new System.Drawing.Size(88, 58);
            this.btn_RemoveCategory.TabIndex = 22;
            this.btn_RemoveCategory.Text = "Remove Category";
            this.btn_RemoveCategory.UseVisualStyleBackColor = false;
            this.btn_RemoveCategory.Click += new System.EventHandler(this.btn_RemoveCategory_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(815, 448);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(183, 170);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OldLace;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1096, 634);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_RemoveCategory);
            this.Controls.Add(this.btn_AddCategory);
            this.Controls.Add(this.btn_RemoveProduct);
            this.Controls.Add(this.btn_EditProduct);
            this.Controls.Add(this.btn_AddProduct);
            this.Controls.Add(this.cb_Category);
            this.Controls.Add(this.tb_NamaCategory);
            this.Controls.Add(this.tb_Stock);
            this.Controls.Add(this.tb_Harga);
            this.Controls.Add(this.tb_NamaProduct);
            this.Controls.Add(this.lb_DStock);
            this.Controls.Add(this.lb_DHarga);
            this.Controls.Add(this.lb_DCategory);
            this.Controls.Add(this.lb_DNama);
            this.Controls.Add(this.lb_NamaCategory);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lb_Category);
            this.Controls.Add(this.cb_Filter);
            this.Controls.Add(this.dgv_Category);
            this.Controls.Add(this.dgv_Product);
            this.Controls.Add(this.btn_Filter);
            this.Controls.Add(this.btn_All);
            this.Controls.Add(this.lb_Product);
            this.Name = "Form1";
            this.Text = "Blink Shop";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_Product;
        private System.Windows.Forms.Button btn_All;
        private System.Windows.Forms.Button btn_Filter;
        private System.Windows.Forms.DataGridView dgv_Product;
        private System.Windows.Forms.DataGridView dgv_Category;
        private System.Windows.Forms.ComboBox cb_Filter;
        private System.Windows.Forms.Label lb_Category;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_NamaCategory;
        private System.Windows.Forms.Label lb_DNama;
        private System.Windows.Forms.Label lb_DCategory;
        private System.Windows.Forms.Label lb_DHarga;
        private System.Windows.Forms.Label lb_DStock;
        private System.Windows.Forms.TextBox tb_NamaProduct;
        private System.Windows.Forms.TextBox tb_Harga;
        private System.Windows.Forms.TextBox tb_Stock;
        private System.Windows.Forms.TextBox tb_NamaCategory;
        private System.Windows.Forms.ComboBox cb_Category;
        private System.Windows.Forms.Button btn_AddProduct;
        private System.Windows.Forms.Button btn_EditProduct;
        private System.Windows.Forms.Button btn_RemoveProduct;
        private System.Windows.Forms.Button btn_AddCategory;
        private System.Windows.Forms.Button btn_RemoveCategory;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

