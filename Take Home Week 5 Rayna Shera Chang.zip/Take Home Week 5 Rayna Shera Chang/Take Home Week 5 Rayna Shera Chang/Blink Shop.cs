﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Take_Home_Week_5_Rayna_Shera_Chang
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public List<string> listID = new List<string>();
        public List<string> listNama = new List<string>();
        public List<int> listHarga = new List<int>();
        public List<int> listStock = new List<int>();
        public List<string> listIDCategoryProduct = new List<string>();
        public List<string> listIDCategory = new List<string>();
        public List<string> listNamaCategory = new List<string>();

        public DataTable dtProdukSimpan = new DataTable();
        public DataTable dtProdukTampil = new DataTable();
        public DataTable dtCategory = new DataTable();

        private DataRow row;
        public string selectedcell;
        private void Form1_Load(object sender, EventArgs e)
        {
            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");

            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");

            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");

            listID.Add("J001");
            listID.Add("T001");
            listID.Add("T002");
            listID.Add("R001");
            listID.Add("J002");
            listID.Add("C001");
            listID.Add("C002");
            listID.Add("R002");

            listNama.Add("Jas Hitam");
            listNama.Add("T-Short Black Pink");
            listNama.Add("T-Shirt Obsessive");
            listNama.Add("Rok Mini");
            listNama.Add("Jeans Biru");
            listNama.Add("Celana Pendek Coklat");
            listNama.Add("Cawat Blink-Blink");
            listNama.Add("Rocca Shirt");

            listHarga.Add(100000);
            listHarga.Add(70000);
            listHarga.Add(75000);
            listHarga.Add(82000);
            listHarga.Add(90000);
            listHarga.Add(60000);
            listHarga.Add(1000000);
            listHarga.Add(50000);

            listStock.Add(10);
            listStock.Add(20);
            listStock.Add(16);
            listStock.Add(26);
            listStock.Add(5);
            listStock.Add(11);
            listStock.Add(1);
            listStock.Add(8);

            listIDCategoryProduct.Add("C1");
            listIDCategoryProduct.Add("C2");
            listIDCategoryProduct.Add("C2");
            listIDCategoryProduct.Add("C3");
            listIDCategoryProduct.Add("C4");
            listIDCategoryProduct.Add("C4");
            listIDCategoryProduct.Add("C5");
            listIDCategoryProduct.Add("C2");

            listIDCategory.Add("C1");
            listIDCategory.Add("C2");
            listIDCategory.Add("C3");
            listIDCategory.Add("C4");
            listIDCategory.Add("C5");

            listNamaCategory.Add("Jas");
            listNamaCategory.Add("T-Shirt");
            listNamaCategory.Add("Rok");
            listNamaCategory.Add("Celana");
            listNamaCategory.Add("Cawat");

            dgv_Product.DataSource = dtProdukSimpan;
            dgv_Category.DataSource = dtCategory;

            foreach(string id in listID)
            {
                int a = listID.IndexOf(id);
                dtProdukSimpan.Rows.Add(listID[a], listNama[a], listHarga[a], listStock[a], listIDCategoryProduct[a]);
            }

            for (int i = 0;i<listIDCategory.Count; i++)
            {
                row = dtCategory.NewRow();
                row[0] = listIDCategory[i];
                row[1] = listNamaCategory[i];
                dtCategory.Rows.Add(row);
            }

            dgv_Category.ClearSelection();
            dgv_Product.ClearSelection();

            foreach(string s in listNamaCategory)
            {
                cb_Category.Items.Add(s);
                cb_Filter.Items.Add(s);
            }

        }

        private void btn_AddProduct_Click(object sender, EventArgs e)
        {
            if(tb_NamaProduct.Text =="" || tb_Harga.Text =="" || tb_Stock.Text =="" || cb_Category.SelectedIndex==-1)
            {
                MessageBox.Show("Input yang lengkap ya", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_Harga.Text = "";
                tb_NamaProduct.Text = "";
                tb_Stock.Text = "";
                cb_Category.SelectedIndex = -1;
                dgv_Category.ClearSelection();
                dgv_Product.ClearSelection();
            }
            else
            {
                string hurufID = tb_NamaProduct.Text.Substring(0, 1).ToUpper();
                int nomorID = 0;
                foreach(string a in listID)
                {
                    char b = a[0];
                    string c = b.ToString();
                    if(c==hurufID)
                    {
                        int nomorID2 = Convert.ToInt32(a.Substring(1));
                        if(nomorID <= nomorID2)
                        {
                            nomorID = nomorID2;
                        }
                    }
                }

                string idproduct = hurufID;
                for (int a = nomorID.ToString().Length;a<3;a++)
                {
                    idproduct = idproduct + "0";
                }

                idproduct = idproduct + (nomorID + 1).ToString();
                int indeks = cb_Category.SelectedIndex;
                string idcat = listIDCategory[indeks];

                listID.Add(idproduct);
                listNama.Add(tb_NamaProduct.Text);
                listHarga.Add(Convert.ToInt32(tb_Harga.Text));
                listStock.Add(Convert.ToInt32(tb_Stock.Text));
                listIDCategoryProduct.Add(idcat);

                row = dtProdukSimpan.NewRow();
                row[0] = idproduct;
                row[1] = tb_NamaProduct.Text;
                row[2] = tb_Harga.Text;
                row[3] = tb_Stock.Text;
                row[4] = idcat;
                dtProdukSimpan.Rows.Add(row);

                tb_Harga.Text = "";
                tb_NamaProduct.Text = "";
                tb_Stock.Text = "";
                cb_Category.SelectedIndex = -1;
                dgv_Category.ClearSelection();
                dgv_Product.ClearSelection();
            }
        }

        private void btn_All_Click(object sender, EventArgs e)
        {
            cb_Filter.Enabled = false;
            cb_Filter.SelectedIndex = -1;
            dgv_Product.DataSource = dtProdukSimpan;
            dgv_Category.ClearSelection();
            dgv_Product.ClearSelection();
        }
        private void btn_EditProduct_Click(object sender, EventArgs e)
        {
            if (dgv_Product.SelectedRows.Count == 0)
            {
                MessageBox.Show("Pilih dulu dong", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_Harga.Text = "";
                tb_NamaProduct.Text = "";
                tb_Stock.Text = "";
                cb_Category.SelectedIndex = -1;
                dgv_Category.ClearSelection();
                dgv_Product.ClearSelection();
            }
            else
            {
                foreach(DataRow row in dtProdukSimpan.Rows)
                {
                    int indekscat = cb_Category.SelectedIndex;
                    int index = listID.FindIndex(a => a.Contains(dgv_Product.CurrentRow.Cells["ID Product"].Value.ToString()));
                    string idbaru = "";
                    if (row[0].ToString() == listID[index])
                    {
                        idbaru = listIDCategory[indekscat];
                        row[1] = tb_NamaProduct.Text;
                        row[2] = tb_Harga.Text;
                        row[3] = tb_Stock.Text;
                        row[4] = idbaru;
                        if (row[3].ToString() == "0")
                        {
                            dtProdukSimpan.Rows.Remove(row);
                            break;
                        }
                    }
                }
                tb_Harga.Text = "";
                tb_NamaProduct.Text = "";
                tb_Stock.Text = "";
                cb_Category.SelectedIndex = -1;
                dgv_Category.ClearSelection();
                dgv_Product.ClearSelection();
            }
        }
        private void btn_RemoveProduct_Click(object sender, EventArgs e)
        {
            if (dgv_Product.SelectedRows.Count != 0)
            {
                int selectedIndex = dgv_Product.CurrentCell.RowIndex;
                dgv_Product.Rows.RemoveAt(selectedIndex);

                listID.RemoveAt(selectedIndex);
                listNama.RemoveAt(selectedIndex);
                listHarga.RemoveAt(selectedIndex);
                listStock.RemoveAt(selectedIndex);
                listIDCategoryProduct.RemoveAt(selectedIndex);

                dtProdukSimpan.Clear();
                foreach (string b in listID)
                {
                    int ii = listID.IndexOf(b);
                    dtProdukSimpan.Rows.Add(listID[ii], listNama[ii], listHarga[ii], listStock[ii], listIDCategoryProduct[ii]);
                }
                tb_Harga.Clear();
                tb_NamaProduct.Clear();
                tb_Stock.Clear();
                cb_Category.SelectedIndex = -1;
                dgv_Category.ClearSelection();
                dgv_Product.ClearSelection();
            }

        }
        private void btn_Filter_Click(object sender, EventArgs e)
        {
            cb_Filter.Enabled = true;
        }

        private void btn_AddCategory_Click(object sender, EventArgs e)
        {
            if(tb_NamaCategory.Text =="")
            {
                MessageBox.Show("Masukkan nama category terlebih dahulu", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_NamaCategory.Text = "";
            }
            else
            {
                int number = 1;
                bool sama = false;
                if(listNamaCategory.Contains(tb_NamaCategory.Text))
                {
                    sama = true;
                }
                if (sama == true)
                {
                    MessageBox.Show("Category udah ada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    tb_NamaCategory.Text = "";
                }
                else if(sama == false)
                {
                    foreach(string b in listIDCategory)
                    {
                        if(b.StartsWith("C"))
                        {
                            int number2 = int.Parse(b.Substring(1));
                            if(number2 >= number)
                            {
                                number = number2 + 1;
                            }
                        }
                    }
                    string idcategory = "C" + (number).ToString();
                    listIDCategory.Add(idcategory);
                    dgv_Category.ClearSelection();
                    cb_Category.Items.Add(tb_NamaCategory.Text);
                    cb_Filter.Items.Add(tb_NamaCategory.Text);
                    listNamaCategory.Add(tb_NamaCategory.Text);
                    dtCategory.Rows.Add(idcategory, tb_NamaCategory.Text);
                    tb_NamaCategory.Text = "";
                }
            }
        }

        private void btn_RemoveCategory_Click(object sender, EventArgs e)
        {
            if(dgv_Category.SelectedRows.Count == 0)
            {
                MessageBox.Show("Pilih dulu dong", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_NamaCategory.Text = "";
                dgv_Category.ClearSelection();
                dgv_Product.ClearSelection();
                return;
            }
            int categoryIndex = dgv_Category.CurrentCell.RowIndex;
            string categoryID = listIDCategory[categoryIndex];
            if(cb_Filter.SelectedIndex != null)
            {
                for (int i = listIDCategoryProduct.Count -1;i>=0;i--)
                {
                    if (listIDCategoryProduct[i] == categoryID)
                    {
                        listID.RemoveAt(i);
                        listNama.RemoveAt(i);
                        listHarga.RemoveAt(i);
                        listStock.RemoveAt(i);
                        listIDCategoryProduct.RemoveAt(i);
                    }
                }
                listIDCategory.RemoveAt(categoryIndex);
                listNamaCategory.RemoveAt(categoryIndex);
                cb_Filter.Items.Remove(dgv_Category.CurrentRow.Cells["Nama Category"].Value.ToString());
                cb_Category.Items.Remove(dgv_Category.CurrentRow.Cells["Nama Category"].Value.ToString());
            
                dgv_Category.Rows.RemoveAt(categoryIndex);
                dtCategory.Rows.Clear();
                foreach(string categoryid in  listIDCategory)
                {
                    int rowIndex = listIDCategory.IndexOf(categoryid);
                    dtCategory.Rows.Add(categoryid, listNamaCategory[rowIndex]);
                }

                dtProdukSimpan.Rows.Clear();
                foreach(string productID in listID)
                {
                    int rowIndex = listID.IndexOf(productID);
                    dtProdukSimpan.Rows.Add(listID[rowIndex], listNama[rowIndex], listHarga[rowIndex], listStock[rowIndex], listIDCategoryProduct[rowIndex]);
                }
                tb_NamaCategory.Text = "";
                dgv_Category.ClearSelection();
                dgv_Product.ClearSelection();
                dgv_Product.DataSource = dtProdukSimpan;
            }
            else
            {
                for(int i = listIDCategoryProduct.Count - 1;i>=0;i--)
                {
                    if (listIDCategoryProduct[i] == categoryID)
                    {
                        listID.RemoveAt(i);
                        listNama.RemoveAt(i);
                        listHarga.RemoveAt(i);
                        listStock.RemoveAt(i);
                        listIDCategoryProduct.RemoveAt(i);
                    }
                }
                listIDCategory.RemoveAt(categoryIndex);
                listNamaCategory.RemoveAt(categoryIndex);
                cb_Filter.Items.Remove(dgv_Category.CurrentRow.Cells["Nama Category"].Value.ToString());    
                cb_Category.Items.Remove(dgv_Category.CurrentRow.Cells["Nama Category"].Value.ToString());

                dgv_Category.Rows.RemoveAt(categoryIndex);
                dtCategory.Rows.Clear();
                foreach (string categoryid in listIDCategory)
                {
                    int rowIndex = listIDCategory.IndexOf(categoryid);
                    dtCategory.Rows.Add(categoryid, listNamaCategory[rowIndex]);
                }

                dtProdukSimpan.Rows.Clear();
                foreach (string productID in listID)
                {
                    int rowIndex = listID.IndexOf(productID);
                    dtProdukSimpan.Rows.Add(listID[rowIndex], listNama[rowIndex], listHarga[rowIndex], listStock[rowIndex], listIDCategoryProduct[rowIndex]);
                }
                tb_NamaCategory.Text = "";
                dgv_Category.ClearSelection();
                dgv_Product.ClearSelection();
                dgv_Product.DataSource = dtProdukSimpan;
            }
        }

        private void tb_Harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar) && (e.KeyChar != '.')))
            {
                e.Handled = true;
            }
        }

        private void tb_Stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar) && (e.KeyChar != '.')))
            {
                e.Handled = true;
            }
        }

        private void dgv_Product_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            tb_NamaProduct.Text = dgv_Product.CurrentRow.Cells["Nama Product"].Value.ToString();
            tb_Harga.Text = dgv_Product.CurrentRow.Cells["Harga"].Value.ToString();
            tb_Stock.Text = dgv_Product.CurrentRow.Cells["Stock"].Value.ToString();
            int index = listIDCategory.FindIndex(a => a.Contains(dgv_Product.CurrentRow.Cells["ID Category"].Value.ToString()));
            string b = listNamaCategory[index];
            cb_Category.Text = b;
        }

        private void cb_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgv_Product.DataSource = dtProdukTampil;
            dtProdukTampil.Clear();
            foreach(DataRow row in dtCategory.Rows)
            {
                if(cb_Filter.Text == row[1].ToString())
                {
                    foreach(DataRow dataRow in dtProdukSimpan.Rows)
                    {
                        if (dataRow["ID Category"].ToString() == row[0].ToString())
                        {
                            dtProdukTampil.Rows.Add(dataRow["ID Product"], dataRow["Nama Product"], dataRow["Harga"], dataRow["STock"], dataRow["ID Category"]);
                        }
                    }
                }
            }
            dgv_Product.ClearSelection();
        }

        private void dgv_Category_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            tb_NamaCategory.Text = dgv_Category.CurrentRow.Cells["Nama Category"].Value.ToString();
        }
    }
}
